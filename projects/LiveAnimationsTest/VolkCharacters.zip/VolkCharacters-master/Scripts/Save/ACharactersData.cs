﻿using System;
using System.Linq;
using ModestTree;
using UnityEngine;
using VolkCore.Game;
using VolkCore.Save;
using VolkCore.Tools;
using Zenject;

namespace VolkCharacters.Save
{
    public class ACharactersData<TCharacter> : ScriptableObject, ICharactersData<TCharacter> ,IInitAsync, IInitializable,IDisposable
        where TCharacter : ACharacterData
    {
        public bool Inited { get;private set; }
        public Action OnInited { get; set; }
        public InitAwaiter GetAwaiter() => new InitAwaiter(this);
        
        public TCharacter SelectedCharacter => _selectedCharacter;
        private TCharacter _selectedCharacter;
        [field: SerializeField] public TCharacter[] Characters { get; private set; }
        protected virtual string CharacterType => "ACharacter";

        private string _characterKey;
        private int _selectedCharacterIndex;
        [Inject] private IDataStorage _storage;

        public async void Initialize()
        {
            _selectedCharacter = await LoadCharacter();
            Inited = true;
            OnInited?.Invoke();
        }
        
        private async Awaitable<TCharacter> LoadCharacter()
        {
            _characterKey = $"{_storage.UserData.ApplicationName}_{CharacterType}";
            if (_storage.Exists(_characterKey))
            {
                _selectedCharacterIndex =  int.Parse(await _storage.LoadDecryptedAsync(_characterKey,false));
            }
            else
            {
                var character = Characters.First(x => x.Id == 0);
                _selectedCharacterIndex = Characters.IndexOf(character);
                await _storage.SaveEncryptedAsync(_characterKey, _selectedCharacterIndex.ToString(), false);
                return character;
            }

            return Characters[_selectedCharacterIndex];
        }
        
        public TCharacter NextCharacter()
        {
            _selectedCharacterIndex = (_selectedCharacterIndex + 1) % Characters.Length;
            _selectedCharacter = Characters[_selectedCharacterIndex];
            return _selectedCharacter;
        }

        public TCharacter PreviousCharacter()
        {
            _selectedCharacterIndex = (_selectedCharacterIndex - 1 + Characters.Length) % Characters.Length;
            _selectedCharacter = Characters[_selectedCharacterIndex];
            return _selectedCharacter;
        }

        public TCharacter GetCharacterById(int id)
        {
            var character = Characters.FirstOrDefault(x => x.Id == id);
            if (character == null)
            {
                Debug.LogError($"Character with id {id} not found");
                return _selectedCharacter;
            }

            _selectedCharacter = character;
            _selectedCharacterIndex = Characters.IndexOf(character);
            return character;
        }

        public async void SaveCharacter()
        {
            await _storage.SaveEncryptedAsync( _characterKey,_selectedCharacter.Id.ToString(), false);
        }
        
        public async void Dispose()
        {
            SaveCharacter();
        }


    }
}