﻿using UnityEngine;
using VolkArkanoid.Save;
using VolkCore.Save;

namespace Packages.VolkArkanoid.Scripts
{
    public class ArkanoidLevels : AGameLevels<LevelData>
    {
        protected override string GameName => "Arkanoid";

        protected async override Awaitable LoadLevels()
        {
            Levels = LevelFactory.GenerateLevels();
        }
    }
}