using UnityEditor;
using UnityEngine;

namespace VolkArkanoid.EditorTools
{
    [CustomEditor(typeof(LevelBuilder))]
    public class LevelBuilderEditor : Editor
    {
        public override void OnInspectorGUI()
        {
            DrawDefaultInspector();

            var builder = (LevelBuilder)target;

            EditorGUILayout.Space();
            EditorGUILayout.LabelField("Level Builder Actions", EditorStyles.boldLabel);

            if (GUILayout.Button("Load Level (Editor)"))
            {
                Undo.RegisterFullObjectHierarchyUndo(builder.gameObject, "Load Level");
                builder.LoadLevel();
                EditorUtility.SetDirty(builder);
            }

            if (GUILayout.Button("Save Level"))
            {
                Undo.RegisterCompleteObjectUndo(builder, "Save Level");
                builder.SaveLevel();
                EditorUtility.SetDirty(builder);
            }
        }
    }
}
