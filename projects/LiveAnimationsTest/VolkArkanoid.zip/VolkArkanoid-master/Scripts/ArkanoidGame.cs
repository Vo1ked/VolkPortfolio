﻿using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using Volk.SceneManagement;
using VolkArkanoid.Abilities;
using VolkArkanoid.Save;
using VolkArkanoid.Signals;
using VolkCharacters.Save;
using VolkCore.Collections;
using VolkCore.Save;
using VolkCore.UI;
using Zenject;

namespace VolkArkanoid
{
    public class ArkanoidGame : IInitializable, IDisposable, IPausable
    {
        [Inject] private ICharactersData<ArkanoidPlayer> _arkanoidCharacters;
        [Inject] private Platform _platform;
        [Inject] private Ball _ball;
        [Inject] private AGameLevels<LevelData> _levels;
        [Inject] private SignalBus _signalBus;
        [Inject] private DiContainer _container;
        [Inject] private TopPanel _topPanel;
        [Inject] private ResultPopup _resultPopup;
        
        private Dictionary<int,BlockData> _blocks = new Dictionary<int,BlockData>();
        private int _currentHeals;
        private float _ballspeed;
        
        public async void Initialize()
        {
            await _levels;
            
            _signalBus.Subscribe<BlockDestroyedSignal>(OnBlockDestroyed);
            _signalBus.Subscribe<FloorRichSignal>(OnFloorRich);

            _resultPopup.OnRetry += Restart;
            StartGame();
        }

        public void Dispose()
        {
            _signalBus.Unsubscribe<BlockDestroyedSignal>(OnBlockDestroyed);
            _signalBus.Unsubscribe<FloorRichSignal>(OnFloorRich);
            _resultPopup.OnRetry -= Restart;
        }

        private void StartGame()
        {
            _blocks.Clear();
            
            var startMagnet = ScriptableObject.CreateInstance<StartMagnet>();
            _signalBus.Fire(new LoadLevelSignal(_levels.CurrentLevel.Level));
            var blocks = _levels.CurrentLevel.Blocks.Where((x)=>x.Destroyable);
            foreach (var block in blocks)
            {
                _blocks.Add(block.BlockId, block);
            }
            
            _platform.SetBallAtPlatform(_ball);
            _currentHeals = _arkanoidCharacters.SelectedCharacter.StartHealth;
            _ballspeed = _arkanoidCharacters.SelectedCharacter.StartBallSpeed;
            _ball.Speed = _ballspeed;
            _container.Inject(startMagnet);
            _platform.SessionAbilities.Add(startMagnet);
            _platform.Initialize(_arkanoidCharacters.SelectedCharacter);

        }

        private void OnFloorRich()
        {
            _currentHeals--;
            if (_currentHeals <= 0)
            {
                _ = _resultPopup.SetLose(0, -1);
                return;
            }
            
        }

        private void Restart()
        {
           StartGame();
        }

        private void OnBlockDestroyed(BlockDestroyedSignal block)
        {
            _blocks.Remove(block.BlockId);
            if (_blocks.Count > 0)
                return; 
            _levels.IncrementLevel();
            _levels.SelectLevel(_levels.CurrentLevelId.Value + 1);
            
            _ = _resultPopup.SetWin(0, -1);
            _ball.Speed = 0;
        }


        public void OnPause()
        {
            _ball.Speed = 0;
        }

        public void OnResume()
        {
            _ball.Speed = _ballspeed;
        }
    }
}