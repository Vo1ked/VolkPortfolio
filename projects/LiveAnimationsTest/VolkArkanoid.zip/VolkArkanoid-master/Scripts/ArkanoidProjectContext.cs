﻿using System;
using Packages.VolkArkanoid.Scripts;
using Save;
using UnityEngine;
using VolkArkanoid.Save;
using VolkCharacters;
using VolkCharacters.Save;
using VolkCore.Game;
using VolkCore.Save;
using Zenject;

namespace VolkArkanoid
{
    public class ArkanoidProjectContext : AProjectInstaller
    {
        [SerializeField] private ArkanoidCharactersData _playerCharactersData;
        [SerializeField] private ManualCreatedLevels _levels;

        private IDataStorage _dataStorage;
        public override void InstallBindings()
        {
            if (!CheckAndLogDependencies())
                return;
            
            
            Container.Bind<ALevelFactory<LevelData>>().FromInstance(_levels).AsSingle();
            Container.Bind(typeof(AGameLevels<LevelData>),typeof(IInitializable),typeof(ILevelProgress)).
                To<ArkanoidLevels>().FromNew().AsSingle();
            Container.Bind(typeof(ICharactersData<ArkanoidPlayer>),typeof(ICharactersData<ACharacterData>)
                    ,typeof(IInitAsync),typeof(IInitializable),typeof(IDisposable))
                .To<ArkanoidCharactersData>().FromScriptableObject(_playerCharactersData).AsSingle();
        }
    }
}