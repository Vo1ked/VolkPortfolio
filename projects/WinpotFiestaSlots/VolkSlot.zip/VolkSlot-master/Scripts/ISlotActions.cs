﻿using System;
using VolkCore.Game;

namespace VolkSlot
{
    public interface ISlotActions : IDisposable
    {
        public event Action SpinStart;
        public event Action SpinEnd;
        public void TrySpin();
        public Icon GetIcon();
        public void AddResult(int reelId, Icon[] result);

    }
}