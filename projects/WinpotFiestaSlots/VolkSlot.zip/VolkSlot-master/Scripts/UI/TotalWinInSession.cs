﻿using TMPro;
using UnityEngine;
using VolkCore.Save;
using Zenject;

namespace VolkSlot.UI
{
    public class TotalWinInSession : MonoBehaviour
    {
        [Inject] private IBalance _balance;
        [SerializeField] private TMP_Text _totalWinInSessionText;
        [SerializeField] private string _stringFormat = "Total win: {0}";
        
        private int _totalWinInSession;
        private void Awake()
        {
            _balance.Balance.Changed += OnBalanceChanged;
            _totalWinInSessionText.text = string.Format(_stringFormat, _totalWinInSession);
        }

        private void OnBalanceChanged(int oldValue, int newValue)
        {
            if (newValue <= oldValue)
                return;
            
            _totalWinInSession += newValue - oldValue;
            _totalWinInSessionText.text = string.Format(_stringFormat, _totalWinInSession);
        }

    }
}