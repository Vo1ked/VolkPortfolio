﻿using System;
using TMPro;
using UnityEngine;
using UnityEngine.UI;
using VolkSlot.UI.Interfaces;

namespace VolkSlot.UI
{
    [RequireComponent(typeof(Button))]
    public class AutoSpinButton : MonoBehaviour, IBottomAutoSpinPanel
    {
        public event Action OnAutoSpin;
        public event Action OnSpinsCountIncrease;
        public event Action OnSpinsCountDecrease;
        
        [SerializeField] private Button _spinCountPlus;
        [SerializeField] private Button _spinCountMinus;
        [SerializeField] private TMP_Text _text;
        public void SetAutoSpinsCount(int count)
        {
            if (_text != null)
            {
                _text.text = count.ToString();
            }
        }

        private Button _button;
        private void Awake()
        {
            _button = GetComponent<Button>();
            _button.onClick.AddListener(() => OnAutoSpin?.Invoke());
            _spinCountPlus?.onClick.AddListener(() => OnSpinsCountIncrease?.Invoke());
            _spinCountMinus?.onClick.AddListener(() => OnSpinsCountDecrease?.Invoke());
        }
    }
}