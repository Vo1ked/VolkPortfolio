﻿using System;
using UnityEngine;
using UnityEngine.UI;
using VolkCore.UI;
using VolkSlot.UI.Interfaces;

namespace VolkSlot.UI
{
    public class AutoSpinPanel : MonoBehaviour,IAutoSpinPanel
    {
        public event Action OnSpinsCountIncrease;
        public event Action OnSpinsCountDecrease;
        public event Action OnAutoSpin;
        [SerializeField] private Button _autoSpin;
        [SerializeField] private ValueModifierPanel _autoSpinsCountPanel;

        private void Awake()
        {
            _autoSpin?.onClick.AddListener(() => OnAutoSpin?.Invoke());
            _autoSpinsCountPanel.OnValueIncrease += () => OnSpinsCountIncrease?.Invoke();
            _autoSpinsCountPanel.OnValueDecrease += () => OnSpinsCountDecrease?.Invoke();
        }
        
        public void SetAutoSpinsCount(int value)
        {
            _autoSpinsCountPanel.SetValue(value);
        }
    }
}