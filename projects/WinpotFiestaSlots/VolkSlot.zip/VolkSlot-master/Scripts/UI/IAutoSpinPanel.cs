﻿using System;

namespace VolkSlot.UI.Interfaces
{
    public interface IAutoSpinPanel
    {
        event Action OnAutoSpin;
        event Action OnSpinsCountIncrease;
        event Action OnSpinsCountDecrease;

        public void SetAutoSpinsCount(int count);
    }
}