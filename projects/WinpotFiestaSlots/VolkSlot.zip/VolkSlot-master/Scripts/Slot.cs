﻿using System;
using UnityEngine;
using VolkCore.Game;
using VolkCore.Game.Level;
using VolkCore.Save;
using VolkCore.UI.Interfaces;
using Zenject;

namespace VolkSlot
{
    public class Slot : ISlotActions
    {
        public event Action SpinStart;
        public event Action SpinEnd;

        private readonly IBet _bet;
        private readonly IBalance _balance;
        private readonly AWinChecker _winChecker;
        private readonly ISpinButton _spinButton;
        private readonly SignalBus _signalBus;
        private readonly IUserLevel _userLevel;

        private IAutoSpins _autoSpin;

        private Icon[,] _spinResult;
        private int _reelStopped;
        private bool _isSpining;

        public Slot(
            IBet bet,
            IBalance balance,
            AWinChecker winChecker,
            ISpinButton spinButton,
            SignalBus signalBus,
            [InjectOptional] IUserLevel userLevel = null)
        {
            _bet = bet;
            _balance = balance;
            _winChecker = winChecker;
            _spinButton = spinButton;
            _signalBus = signalBus;
            _signalBus.Subscribe<AutoSpinsSignal>(OnAutoSpin);
            _userLevel = userLevel;
            _spinResult = new Icon[_winChecker.Size.x,_winChecker.Size.y];
            _spinButton.OnSpin += TrySpin;
            _spinButton.SetSpinInteract(_balance.Balance.Value > _bet.CurrentBet);
        }

        private void OnAutoSpin(AutoSpinsSignal autoSpins)
        {
            _autoSpin = autoSpins.AutoSpins;
            if (_autoSpin.IsAutoSpin)
            {
                TrySpin();
            }
        }

        public void Dispose()
        {
            _spinButton.OnSpin -= TrySpin;
            _signalBus.Unsubscribe<AutoSpinsSignal>(OnAutoSpin);
        }

        public  void TrySpin()
        {
            if (_balance.Balance.Value < _bet.CurrentBet)
            {
                _spinButton.SetSpinInteract(false);
                return;
            }

            if (_isSpining)
                return;
            if (_userLevel != null)
            {
                _userLevel.Experience.Value += 1; 
            }
            _balance.Balance.Value -= _bet.CurrentBet;
            _winChecker.OnSpinBet = _bet.CurrentBet;
            Spin();
        }

        private void Spin()
        {
            _spinButton.SetSpinInteract(false);
            _spinResult = new Icon[_winChecker.Size.x,_winChecker.Size.y];
            _reelStopped = 0;
            _isSpining = true;
            SpinStart?.Invoke();
        }

        public Icon GetIcon()
        {
            return new Icon(_winChecker.Icons.GetRandomItem());
        }

        public async void AddResult(int reelId, Icon[] result)
        {
            if (_spinResult[0,reelId] != null)
            {
                Debug.LogWarning($" reel with id {reelId} rewrite result!");
            }
            
            for (var i = 0; i < result.Length; i++)
            {
                _spinResult[i, reelId] = result[i];
            }

            _reelStopped++;

            if (_reelStopped < _winChecker.Size.y)
                return;

            await _winChecker.CheckWin(_spinResult);


            _isSpining = false;
            SpinEnd?.Invoke();
            _spinButton.SetSpinInteract(true);
            if (_autoSpin is not { IsAutoSpin: true })
                return;
            
            _spinButton.SetSpinInteract(false);
            await Awaitable.WaitForSecondsAsync(_autoSpin.SpinDelay);
            TrySpin();
        }
    }
}

