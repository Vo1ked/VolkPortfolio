﻿using System.Threading.Tasks;
using UnityEngine;
using VolkCore.Game;
using VolkCore.Save;
using VolkCore.UI;
using Zenject;

namespace VolkSlot
{
    [CreateAssetMenu(fileName = "WinChecker", menuName = "Volk/Slot/WinChecker")]
    public class WinChecker : AWinChecker
    {
        [Inject] private ResultPopup _winPopup;
        [Inject] private IBalance _balance;
        
        public override async Task CheckWin(Icon[,] data)
        {
            int totalWin = TotalWin(data);
            if (totalWin > 0)
            {
                await _winPopup.SetWin(totalWin,2.5f);
                _balance.Balance.Value += totalWin;
            }
        }

        private int TotalWin(Icon[,] data)
        {
            var totalWin = 0;
            for (int i = 0; i < data.GetLength(0); i++)
            {
                var item = data[i, 0];
                for (int j = 0; j < data.GetLength(1); j++)
                {
                    int iconId = data[i, j].IconId;
                    if (item.IconId != iconId)
                    {
                        item = null;
                        break;
                    }
                    item = data[i, j];
                }

                if (item == null)
                    continue;
                
                totalWin += Mathf.FloorToInt(_icons.Items.Find(icon => icon.Data.IconId == item.IconId).Data.Cost * OnSpinBet);
                
                if (UserLevel != null)
                {
                    UserLevel.Experience.Value += OnSpinBet; 
                }
            }

            return totalWin;
        }
    }
}