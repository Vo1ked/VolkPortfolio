﻿using UnityEngine;
using VolkCore.Game;
using VolkCore.Collections;
using VolkCore.Game.Level;
using VolkCore.Save;

namespace VolkSlot
{
    public class SlotProjectContext : ASceneInstaller
    {
        [SerializeField] private int[] _bets = { 50, 100 , 200, 400, 500, 750, 1000, 1500, 2000, 4000, 5000, 10000};
        public override void InstallBindings()
        {
            if (!CheckAndLogDependencies())
                return;
            
            Container.Bind<int[]>().WithId("Bets").FromInstance(_bets).AsSingle();
            Container.Bind<IBet>().To<Bet>().AsSingle().NonLazy();
            Container.Bind(typeof(IBalance),typeof(System.IDisposable)).To<UserBalance>().AsSingle().NonLazy();
            Container.Bind<IUserLevel>().To<UserLevel>().AsSingle().NonLazy();
            Container.Bind<WinMultiplierAggregator>().FromNew().AsSingle().NonLazy();
        }
    }
}