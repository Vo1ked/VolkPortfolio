﻿using System.Collections.Generic;
using System.Threading.Tasks;
using UnityEngine;
using VolkCore.Game;
using VolkCore.Save;
using VolkCore.UI;
using Zenject;

namespace VolkSlot
{
    [CreateAssetMenu(fileName = "WinCheckerWithDuplicateCheck", menuName = "Volk/Slot/WinCheckerWithDuplicateCheck")]
    public class WinCheckerWithDuplicateCheck : AWinChecker
    {
        [Inject] private ResultPopup _winPopup;
        [Inject] private IBalance _balance;

        private List<List<Icon>> _previousWinningCombination = new List<List<Icon>>();

        public override async Task CheckWin(Icon[,] data)
        {
            var totalWin = TotalWin(data, out var winningCombination);

            if (HasSameWinningCombination(winningCombination))
            {
                totalWin = 0;
            }

            _balance.Balance = _balance.Balance; // updated to know total win
            if (totalWin > 0)
            {
                await _winPopup.SetWin(totalWin, 2.5f);
                _balance.Balance.Value += totalWin;
            }

            _previousWinningCombination = winningCombination;
        }
        
        private int TotalWin(Icon[,] data, out List<List<Icon>> winCombinations)
        {
            var totalWin = 0;
            var winCombination = new List<Icon>();
            winCombinations = new List<List<Icon>>();
            for (int i = 0; i < data.GetLength(0); i++)
            {
                var item = data[i, 0];
                int count = 1;

                for (int j = 1; j < data.GetLength(1); j++)
                {
                    if (item.IconId == data[i, j].IconId)
                    {
                        count++;
                        winCombination.Add(data[i, j]);
                    }
                    else
                    {
                        winCombination.Clear();
                        break;
                    }
                }
                
                if (count < 3)
                    continue;
                
                winCombinations.Add(winCombination);
                var iconData = _icons.Items.Find(icon => icon.Data.IconId == item.IconId).Data;
                var multiplier = 1;
                if (count == 3)
                {
                    totalWin += Mathf.FloorToInt(iconData.Cost * multiplier * OnSpinBet);
                }
                else
                {
                    multiplier = 2;
                    totalWin += Mathf.FloorToInt(iconData.Cost * multiplier * OnSpinBet);
                }

                if (UserLevel != null)
                {
                    UserLevel.Experience.Value += OnSpinBet * multiplier;
                }
            }

            return totalWin;
        }

        private bool HasSameWinningCombination(List<List<Icon>> currentWinningCombination)
        {
            if (_previousWinningCombination.Count < 1 || currentWinningCombination.Count != _previousWinningCombination.Count)
                return false;
            
            for (int i = 0; i < currentWinningCombination.Count; i++)
            {
                var previousCombination = _previousWinningCombination[i];
                var currentCombination = currentWinningCombination[i];

                if (previousCombination.Count != currentCombination.Count)
                    return false;

                for (int j = 0; j < currentCombination.Count; j++)
                {
                    if (previousCombination[j].IconId != currentCombination[j].IconId)
                        return false;
                }
            }

            return true;
        }
    }
}
