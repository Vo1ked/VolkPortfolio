﻿namespace VolkSlot
{
    public class AutoSpinsSignal
    {
        public readonly IAutoSpins AutoSpins;

        public AutoSpinsSignal(IAutoSpins autoSpins)
        {
            AutoSpins = autoSpins;
        }
    }
}