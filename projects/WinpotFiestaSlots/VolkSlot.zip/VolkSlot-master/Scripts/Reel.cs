﻿using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using VolkCore.Collections;
using UnityEngine;
using VolkCore.Game;
using Zenject;

namespace VolkSlot
{
    public class Reel : MonoBehaviour ,IPausable
    {
        [Inject] protected ISlotActions Slot;
        [Inject] private IconContainer _iconContainer;

        [SerializeField] protected int _reelId;
        [SerializeField] private int _iconsCount = 3;
        [SerializeField] private Vector2 _cellSize = new Vector2(30, 30);
        [SerializeField] private float _startDelay = 0;
        [SerializeField] private Direction _direction;
        [SerializeField] private float _rotationTime = 2.5f;
        [SerializeField] private float _rotationSpeed = 10;
        [SerializeField] private float offset;
        [SerializeField] private RectTransform _container;
        private bool _isPaused = false; 
        private CancellationTokenSource _cancellationTokenSource;
        private IconContainer[] _icons;

        private float StartPosition
        {
            get
            {
                //TODO add correct work for var direction = _direction == Direction.Down ? _cellSize.y : _cellSize.x;

                float visibleIconsHeight = (_cellSize.y + offset) * _iconsCount;
                float totalOffset = (_cellSize.y + offset) * 1.5f;

                return visibleIconsHeight / 2 + totalOffset;
            }
        }

        private void Awake()
        {
            _icons = new IconContainer[_iconsCount + 4];
            _cancellationTokenSource = new CancellationTokenSource();
            for (int i = 0; i < _iconsCount + 4; i++)
            {
                CreateAndPositionIcon(i);
            }

            Slot.SpinStart += OnStartSpin;
        }

        private void OnDestroy()
        {
            _cancellationTokenSource?.Cancel(); 
            Slot.SpinStart -= OnStartSpin;
        }

        private void CreateAndPositionIcon(int index)
        {
            var icon = Slot.GetIcon();

            icon.Position = new Vector2Int(index - 2, _reelId);
            var iconContainer = Instantiate(_iconContainer, _container);
            iconContainer.transform.localPosition = GetIconPosition(index);
            iconContainer.Icon = icon;
            _icons[index] = iconContainer;
        }

        private Vector3 GetIconPosition(int index)
        {
            return _direction == Direction.Down
                ? new Vector3(0, StartPosition - (_cellSize.y + offset) * index, 0)
                : new Vector3((_cellSize.x + offset) * index, StartPosition, 0);
        }

        protected  virtual async void OnStartSpin()
        {
            await Awaitable.WaitForSecondsAsync(_startDelay,_cancellationTokenSource.Token);

            await SpinIconsAsync(_cancellationTokenSource.Token);
            await AlignIconsToGrid(_cancellationTokenSource.Token);
            Slot.AddResult(_reelId, GetResult());
        }

        protected Icon[] GetResult()
        {
            var result = new Icon[_iconsCount];

            for (int i = 0; i < _iconsCount; i++)
            {
                result[i] = _icons.First(icon=>icon.Icon.Position.x == i).Icon;
            }
            
            return result;
        }

        private async Task SpinIconsAsync(CancellationToken token)
        {
            float elapsedTime = 0f;
            Vector3 translationDirection = _direction == Direction.Down ? Vector3.down : Vector3.right;

            while (elapsedTime < _rotationTime)
            {
                if (_isPaused)
                {
                    await Awaitable.WaitForSecondsAsync(0.1f,token);
                    continue;
                }
                
                elapsedTime += Time.deltaTime;

                foreach (var icon in _icons)
                {
                    if (token.IsCancellationRequested) 
                        return; 
                    
                    icon.transform.Translate(translationDirection * _rotationSpeed * Time.deltaTime, Space.Self);

                    float boundaryPosition = _direction == Direction.Down
                        ? icon.transform.localPosition.y
                        : icon.transform.localPosition.x;

                    if (boundaryPosition <= -StartPosition)
                    {
                        OnIconReachEnd(icon);
                    }
                }

                await Awaitable.NextFrameAsync(token);
            }
        }

        private void OnIconReachEnd(IconContainer iconContainer)
        {
            var newIcon = Slot.GetIcon();
            var newPosition = _icons.First(icon=>icon.Icon.Position.x == -2).transform.localPosition;

            if (_direction == Direction.Down)
            {
                newPosition.y = newPosition.y + _cellSize.y + offset;
            }
            else
            {
                newPosition.x = newPosition.x + _cellSize.x + offset;
            }

            iconContainer.transform.localPosition = newPosition;

            newIcon.Position = new Vector2Int(-3, _reelId);
            iconContainer.Icon = newIcon;

            foreach (var icon in _icons)
            {
                icon.Icon.Position += Vector2Int.right;
            }

        }


        private async Task AlignIconsToGrid(CancellationToken token)
        {
            if (token.IsCancellationRequested) return; 
            float iconHeightWithOffset = _cellSize.y + offset;

            var currentY = _icons[0].transform.localPosition.y;
            var targetY = StartPosition - (iconHeightWithOffset * (_icons[0].Icon.Position.x + 2));

            if (Mathf.Abs(currentY - targetY) > iconHeightWithOffset / 2)
            {
                var lastIcon = _icons[0];
                foreach (var icon in _icons)
                {
                    if (lastIcon.Icon.Position.x < icon.Icon.Position.x)
                    {
                        lastIcon = icon;
                    }
                }
                if (token.IsCancellationRequested) return; 
                OnIconReachEnd(lastIcon);
            }


            foreach (var iconContainer in _icons)
            {
                if (token.IsCancellationRequested) return; 
                float newY = StartPosition - iconHeightWithOffset * (iconContainer.Icon.Position.x + 2);
                var currentPosition = iconContainer.transform.localPosition;
                currentPosition.y = newY;
                iconContainer.transform.localPosition = currentPosition;
            }

            await Awaitable.NextFrameAsync(token);
        }

        public void OnPause()
        {
            _isPaused = true;
        }

        public void OnResume()
        {
            _isPaused = false;
        }

        protected void OnDrawGizmosSelected()
        {
            Gizmos.color = Color.green;
            for (int i = 0; i < _iconsCount + 4; i++)
            {
                Vector3 worldPosition = transform.TransformPoint(GetIconPosition(i));
                Gizmos.DrawWireCube(worldPosition, _cellSize /100);
            }
        }
        
        [ContextMenu("Resize")]
        public void Resize()
        {
            var rect = transform as RectTransform;

            if (rect == null)
                return;
            float totalHeight = (_cellSize.y + offset) * _iconsCount;
        
            rect.sizeDelta = new Vector2(rect.sizeDelta.x, totalHeight);
        }


        private enum Direction
        {
            Down,
            Right
        }


    }
}


