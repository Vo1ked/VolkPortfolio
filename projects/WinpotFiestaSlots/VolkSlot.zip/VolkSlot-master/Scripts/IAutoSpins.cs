﻿namespace VolkSlot
{
    public interface IAutoSpins
    {
        public bool IsAutoSpin { get; }
        public int SpinDelay { get; }
    }
}