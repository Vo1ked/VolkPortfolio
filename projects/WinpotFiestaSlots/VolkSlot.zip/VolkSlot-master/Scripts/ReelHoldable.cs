﻿using VolkCore.Collections;

namespace VolkSlot
{
    public class ReelHoldable : Reel , IPausable
    {
        private bool _isHold;
        public void SwitchHoldStatus()
        {
            _isHold = !_isHold;
        }
        protected override void OnStartSpin()
        {
            if (_isHold)
            {
                Slot.AddResult(_reelId,GetResult());
                return;
            }
            base.OnStartSpin();
        }
    }
}