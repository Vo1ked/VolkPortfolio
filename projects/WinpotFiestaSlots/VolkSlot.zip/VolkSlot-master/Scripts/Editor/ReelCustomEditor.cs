﻿using UnityEditor;

namespace VolkSlot
{
    [CanEditMultipleObjects]
    [CustomEditor(typeof(Reel), true)]
    public class ReelCustomEditor : Editor
    {
        SerializedProperty scriptProperty;

        private void OnEnable()
        {
            scriptProperty = serializedObject.FindProperty("m_Script");
        }

        public override void OnInspectorGUI()
        {
            serializedObject.Update();

            using (new EditorGUI.DisabledGroupScope(false))
            {
                EditorGUILayout.PropertyField(scriptProperty);
            }

            DrawPropertiesExcluding(serializedObject, "m_Script");

            serializedObject.ApplyModifiedProperties();
        }
    }
}
