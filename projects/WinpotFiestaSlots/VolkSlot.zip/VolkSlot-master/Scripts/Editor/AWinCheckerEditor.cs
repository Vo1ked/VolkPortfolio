﻿using UnityEditor;
using VolkCore.Game;

namespace VolkSlot
{
    [CustomEditor(typeof(AWinChecker), true)]
    public class AWinCheckerCustomEditor : Editor
    {
        SerializedProperty scriptProperty;

        private void OnEnable()
        {
            scriptProperty = serializedObject.FindProperty("m_Script");
        }

        public override void OnInspectorGUI()
        {
            serializedObject.Update();

            using (new EditorGUI.DisabledGroupScope(false))
            {
                EditorGUILayout.PropertyField(scriptProperty);
            }

            DrawPropertiesExcluding(serializedObject, "m_Script");

            serializedObject.ApplyModifiedProperties();
        }
    }
}