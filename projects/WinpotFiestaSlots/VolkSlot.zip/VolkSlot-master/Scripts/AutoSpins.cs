﻿using System;
using VolkCore.UI.Interfaces;
using VolkSlot.UI.Interfaces;
using Zenject;

namespace VolkSlot
{
    public class AutoSpins : IAutoSpins,IDisposable
    {
        public bool IsAutoSpin { get; private set; }
        public int SpinDelay { get; }
        private readonly IAutoSpinPanel _autoSpinPanel;
        private readonly SignalBus _signalBus;
        
        public AutoSpins(IAutoSpinPanel autoSpinPanel,SignalBus signalBus)
        {
            _autoSpinPanel = autoSpinPanel;
            _signalBus = signalBus;
            _autoSpinPanel.OnAutoSpin += AutoSpin;
        }
        
        private void AutoSpin()
        {
            IsAutoSpin = !IsAutoSpin;
            _signalBus.Fire(new AutoSpinsSignal(this));
        }
        
        public void Dispose()
        {
            _autoSpinPanel.OnAutoSpin -= AutoSpin;
        }
    }
}