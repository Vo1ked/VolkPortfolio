﻿using UnityEngine;
using UnityEngine.UI;
using VolkCore.Game;

namespace VolkSlot
{
    public class IconContainer : MonoBehaviour
    {
        [SerializeField] private Image _image;
        [SerializeField] private Icon _icon;
        
        public Icon Icon
        {
            set
            {
                _icon = value;
                _image.sprite = _icon.Sprite;
                _image.SetNativeSize();
            }
            get => _icon;
        }
    }
}