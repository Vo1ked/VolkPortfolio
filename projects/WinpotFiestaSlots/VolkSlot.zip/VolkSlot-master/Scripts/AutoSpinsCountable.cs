﻿using System;
using VolkSlot.UI.Interfaces;
using Zenject;

namespace VolkSlot
{
    public class AutoSpinsCountable : IAutoSpins,IDisposable
    {
        public bool IsAutoSpin { get; private set; }
        public int SpinDelay  => 500;
        private readonly IAutoSpinPanel _autoSpinPanel;
        private readonly ISlotActions _slot;
        private readonly SignalBus _signalBus;
        private readonly int _spinsCount = 10;
        private readonly int _step = 5;
        
        private int _currentSpinsCount = 0;
 
        public AutoSpinsCountable(IAutoSpinPanel autoSpinPanel,ISlotActions slot,SignalBus signalBus)
        {
            _autoSpinPanel = autoSpinPanel;
            _slot = slot;
            _autoSpinPanel.SetAutoSpinsCount(_spinsCount);
            _autoSpinPanel.OnAutoSpin += AutoSpin;
            _autoSpinPanel.OnSpinsCountIncrease += AtSpinsCountIncrease;
            _autoSpinPanel.OnSpinsCountDecrease += AtSpinsCountDecrease;
            _slot.SpinStart += ReduceSpinCount;
            _signalBus = signalBus;
            
            _currentSpinsCount = _spinsCount;
        }

        private void ReduceSpinCount()
        {
            if (!IsAutoSpin)
                return;
            
            ChangeAutoSpinsCount(--_currentSpinsCount);
        }

        private void AtSpinsCountDecrease()
        {
            ChangeAutoSpinsCount(_currentSpinsCount -_step);
        }

        private void AtSpinsCountIncrease()
        {
            ChangeAutoSpinsCount(_currentSpinsCount +_step);
        }

        private void ChangeAutoSpinsCount(int value)
        {
            _currentSpinsCount = value;
            if (_currentSpinsCount <= 0)
            {
                IsAutoSpin = false;
                _slot.SpinEnd += ResetSpinCount;
            }
            _autoSpinPanel.SetAutoSpinsCount(_currentSpinsCount);

        }

        private void AutoSpin()
        {
            if (IsAutoSpin || _currentSpinsCount <= 0)
            {
                IsAutoSpin = false;
                ChangeAutoSpinsCount(_spinsCount);
            }
            else
            {
                IsAutoSpin = true;
            }
            _signalBus.Fire(new AutoSpinsSignal(this));
        }

        private void ResetSpinCount()
        {
            _slot.SpinEnd  -= ResetSpinCount;
            ChangeAutoSpinsCount(_spinsCount);
        }


        public void Dispose()
        {
            _autoSpinPanel.OnAutoSpin -= AutoSpin;
            _autoSpinPanel.OnSpinsCountIncrease -= AtSpinsCountIncrease;
            _autoSpinPanel.OnSpinsCountDecrease -= AtSpinsCountDecrease;
            _slot.SpinStart -= ReduceSpinCount;
            _slot.SpinEnd  -= ResetSpinCount;
        }
    }
}