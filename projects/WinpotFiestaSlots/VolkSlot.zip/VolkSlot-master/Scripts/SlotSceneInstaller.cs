﻿using System;
using UnityEngine;
using VolkCore.Collections;
using VolkCore.Game;
using VolkCore.Signals;
using VolkCore.UI;
using VolkCore.UI.Interfaces;
using VolkSlot.UI;
using VolkSlot.UI.Interfaces;
using Zenject;

namespace VolkSlot
{
    public class SlotSceneInstaller : ASceneInstaller
    {
        [SerializeField] private TopPanel _topPanel;
        [SerializeField] private ResultPopup _resultPopup;
        [SerializeField] private AWinChecker _winChecker;
        [SerializeField] private SpinButton spinButton;
        [SerializeField] private IconContainer _iconContainer;
        [SerializeField] private AutoSpinsType _autoSpinsType = AutoSpinsType.AutoSpinsMock;
        [SerializeField] [OptionalDependency] private AutoSpinPanel _autoSpinPanel;
        [SerializeField] [OptionalDependency] private ValueModifierPanel _multiplierPanel;

        [Inject] private WinMultiplierAggregator _winMultiplierAggregator;
        private IWinMultiplier _winMultiplier;
        public override void InstallBindings()
        {
            if (!CheckAndLogDependencies())
                return;
            
            Container.DeclareSignal<AutoSpinsSignal>();
            Container.Bind<TopPanel>().FromInstance(_topPanel).AsSingle();
            Container.Bind<ResultPopup>().FromInstance(_resultPopup).AsSingle();
            Container.Bind<AWinChecker>().FromInstance(_winChecker).AsSingle();
            Container.Bind<ISpinButton>().FromInstance(spinButton).AsSingle();
            Container.Bind(typeof(ISlotActions), typeof(IDisposable)).To<Slot>().FromNew().AsSingle();
            Container.Bind<IconContainer>().FromInstance(_iconContainer).AsSingle();
            Container.DeclareSignal<StartGameSignal>().OptionalSubscriber();
            BindAutoSpins();
        }

        private void BindAutoSpins()
        {
            switch (_autoSpinsType)
            {
                case AutoSpinsType.AutoSpinsMock:
                    Container.Bind<IAutoSpinPanel>().FromInstance(_autoSpinPanel).AsSingle();
                    Container.Bind<IAutoSpins>().To<AutoSpinsMock>().AsSingle().Lazy();
                    return;
                case AutoSpinsType.AutoSpins:
                    Container.Bind<IAutoSpinPanel>().FromInstance(_autoSpinPanel).AsSingle();
                    Container.Bind<IAutoSpins>().To<AutoSpins>().AsSingle();
                    break;
                case AutoSpinsType.AutoSpinsCountable:
                    Container.Bind<IAutoSpinPanel>().FromInstance(_autoSpinPanel).AsSingle();
                    Container.Bind<IAutoSpins>().To<AutoSpinsCountable>().AsSingle();
                    break;
                case AutoSpinsType.AutoSpinsCountableWithMultiplier:
                    Container.Bind<IAutoSpinPanel>().FromInstance(_autoSpinPanel).AsSingle();
                    Container.Bind<ValueModifierPanel>().WithId("MultiplierPanel").FromInstance(_multiplierPanel);
                    Container.Bind(typeof(IAutoSpins),typeof(IWinMultiplier)).To<AutoSpinsCountableWithMultiplier>().AsSingle();
                    break;
                default:
                    Debug.LogError($"Unsupported AutoSpinsType: {_autoSpinsType}");
                    break;
            }
        }

        public override void Start()
        {
            base.Start();
            Container.Inject(_winChecker);
            var autoSpins = Container.Resolve<IAutoSpins>();
            if (autoSpins is not IWinMultiplier winMultiplier)
                return;
            _winMultiplier = winMultiplier;
            _winMultiplierAggregator.AddItem(_winMultiplier);
        }

        private void OnDestroy()
        {
            if (_autoSpinPanel is not null)
            {
                _winMultiplierAggregator.RemoveItem(_winMultiplier);
            }
        }

        private enum AutoSpinsType
        {
            AutoSpinsMock,
            AutoSpins,
            AutoSpinsCountable,
            AutoSpinsCountableWithMultiplier
        }
    }

    internal class AutoSpinsMock : IAutoSpins
    {
        public bool IsAutoSpin=>false;
        public int SpinDelay=>0;
    }
}
