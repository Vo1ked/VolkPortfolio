﻿using System.Threading.Tasks;
using UnityEngine;
using VolkCore.Game;
using VolkCore.Game.Level;
using VolkCore.Save;
using VolkCore.UI;
using Zenject;

namespace VolkSlot
{
    [CreateAssetMenu(fileName = "CustomWinChecker", menuName = "Volk/Slot/CustomWinChecker")]
    public class CustomWinChecker : AWinChecker
    {
        [Inject] private ResultPopup _winPopup;
        [Inject] private IBalance _balance;
        [InjectOptional] private IUserLevel _level;
        
        public override async Task CheckWin(Icon[,] data)
        {
            int totalWin = TotalWin(data);

            _balance.Balance = _balance.Balance; // udpated for know total win
            if (totalWin > 0)
            {
                await _winPopup.SetWin(totalWin, 2.5f);
                _balance.Balance.Value += totalWin;
            }
        }

        private int TotalWin(Icon[,] data)
        {
            var totalWin = 0;
            for (int i = 0; i < data.GetLength(0); i++)
            {
                var item = data[i, 0];
                int count = 1;

                for (int j = 1; j < data.GetLength(1); j++)
                {
                    if (item.IconId == data[i, j].IconId)
                    {
                        count++;
                    }
                    else
                    {
                        break;
                    }
                }

                if (count < 3)
                    continue;
                
                var iconData = _icons.Items.Find(icon => icon.Data.IconId == item.IconId).Data;
                var multiplier = 1;
                if (count == 3)
                {
                    totalWin += Mathf.FloorToInt(iconData.Cost * OnSpinBet);
                }
                else
                {
                    totalWin += Mathf.FloorToInt((iconData.Cost * 2) * OnSpinBet);
                    multiplier = 2;

                }

                if (_level != null)
                {
                    _level.Experience.Value += OnSpinBet * multiplier;
                }
            }

            return totalWin;
        }
    }
}