﻿using System;
using VolkCore.Collections;
using VolkCore.UI;
using VolkSlot.UI.Interfaces;
using Zenject;

namespace VolkSlot
{
    public class AutoSpinsCountableWithMultiplier : IAutoSpins, IDisposable, IWinMultiplier
    {
        public bool IsAutoSpin { get; private set; } = false;
        public int SpinDelay  => 500;
        private readonly IAutoSpinPanel _autoSpinPanel;
        private readonly ValueModifierPanel _multiplierPanel;
        private readonly ISlotActions _slot;
        private readonly SignalBus _signalBus;
        private readonly int _spinsCount = 10;
        private readonly int _step = 5;
        
        private int _currentSpinsCount = 0;
        private int _currentMultiplierId = 0;
        private readonly int[] _multipliers = {2,4,6,8,10};
        private int _autoSpinsPass = 0;
 
        public AutoSpinsCountableWithMultiplier(
            SignalBus signalBus,
            IAutoSpinPanel autoSpinPanel,
            ISlotActions slot,
            [Inject(Id = "MultiplierPanel")] ValueModifierPanel multiplierPanel)
        {
            _autoSpinPanel = autoSpinPanel;
            _slot = slot;
            _signalBus = signalBus;
            _autoSpinPanel.SetAutoSpinsCount(_spinsCount);
            _autoSpinPanel.OnAutoSpin += AutoSpin;
            _autoSpinPanel.OnSpinsCountIncrease += AtSpinsCountIncrease;
            _autoSpinPanel.OnSpinsCountDecrease += AtSpinsCountDecrease;
            _slot.SpinStart += ReduceSpinCount;
            _multiplierPanel = multiplierPanel;
            _multiplierPanel.OnValueIncrease += AtMultiplierIncrease;
            _multiplierPanel.OnValueDecrease += AtMultiplierDecrease;
            _multiplierPanel.SetValue(_multipliers[_currentMultiplierId]);
            _currentSpinsCount = _spinsCount;
        }

        private void ReduceSpinCount()
        {
            if (!IsAutoSpin)
                return;
            _autoSpinsPass++;
            ChangeAutoSpinsCount(--_currentSpinsCount);
        }

        private void AtSpinsCountDecrease()
        {
            ChangeAutoSpinsCount(_currentSpinsCount - _step);
            if (_currentSpinsCount < 0)
            {
                ChangeAutoSpinsCount(0);
            }
        }

        private void AtSpinsCountIncrease()
        {
            ChangeAutoSpinsCount(_currentSpinsCount + _step);
        }
        
        private void AtMultiplierDecrease()
        {
            _currentMultiplierId = (--_currentMultiplierId + _multipliers.Length) % _multipliers.Length;
            _multiplierPanel.SetValue(_multipliers[_currentMultiplierId]);
        }

        private void AtMultiplierIncrease()
        {
            _currentMultiplierId = ++_currentMultiplierId % _multipliers.Length;
            _multiplierPanel.SetValue(_multipliers[_currentMultiplierId]);
        }

        private void ChangeAutoSpinsCount(int value)
        {
            _currentSpinsCount = value;
            if (_currentSpinsCount <= 0)
            {
                IsAutoSpin = false;
                _slot.SpinEnd += ResetSpinCount;
            }
            _autoSpinPanel.SetAutoSpinsCount(_currentSpinsCount);

        }

        private void AutoSpin()
        {
            if (IsAutoSpin || _currentSpinsCount <= 0)
            {
                IsAutoSpin = false;
                ChangeAutoSpinsCount(_spinsCount);
            }
            else
            {
                _autoSpinsPass = 0;
                IsAutoSpin = true;      
            }

            _signalBus.Fire(new AutoSpinsSignal(this));
        }

        private void ResetSpinCount()
        {
            _slot.SpinEnd  -= ResetSpinCount;
            ChangeAutoSpinsCount(_spinsCount);
        }


        public void Dispose()
        {
            _autoSpinPanel.OnAutoSpin -= AutoSpin;
            _autoSpinPanel.OnSpinsCountIncrease -= AtSpinsCountIncrease;
            _autoSpinPanel.OnSpinsCountDecrease -= AtSpinsCountDecrease;
            _multiplierPanel.OnValueIncrease -= AtMultiplierIncrease;
            _multiplierPanel.OnValueDecrease -= AtMultiplierDecrease;
            _slot.SpinStart -= ReduceSpinCount;
            _slot.SpinEnd  -= ResetSpinCount;
        }

        public int MultiplyWin(int baseWin)
        {
            if (_autoSpinsPass > 4)
            {
                return baseWin * _multipliers[_currentMultiplierId];
            }

            return baseWin;
        }
    }
}