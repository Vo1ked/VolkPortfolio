using VolkBird.Save;
using VolkCore.Save;
using VolkCore.UI;
using Zenject;
using Timer = VolkCore.Game.Timer;

namespace VolkBird
{
    public class BirdData
    {
        [Inject] public BirdLevelBuilder LevelBuilder { get; private set; }
        [Inject] public AGameLevels<LevelData> Levels { get; private set; }
        [Inject] public Bird Bird { get; private set; }
        [Inject] public Timer Timer { get; private set; }
        [Inject] public IBalance Balance { get; private set; }
        [Inject] public ResultPopup ResultPopup { get; private set; }
        [Inject] public SignalBus SignalBus { get; private set; }
    }
}