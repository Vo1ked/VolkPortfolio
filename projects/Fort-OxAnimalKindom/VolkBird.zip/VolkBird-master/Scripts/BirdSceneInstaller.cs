﻿using System;
using Save;
using UnityEngine;
using VolkBird.Collections;
using VolkBird.ItemPools;
using VolkBird.Save;
using VolkBird.Signals;
using VolkCore.Collections;
using VolkCore.Game;
using VolkCore.Save;
using VolkCore.SceneManagement;
using VolkCore.Signals;
using VolkCore.UI;
using Zenject;

namespace VolkBird
{
    public class BirdSceneInstaller : ASceneInstaller
    {
        [SerializeField] private TopPanel _topPanel;
        [SerializeField] private ResultPopup _resultPopup;
        [SerializeField] private string _timerUiFormat = "TIME: {0}";
        [Space]
        [SerializeField] private ALevelFactory<LevelData> _levelFactory;
        [SerializeField] private Spike _spikePrefab;
        [SerializeField] private Candy _candyPrefab;
        [SerializeField] private Bird _bird;
        [Space]
        [SerializeField] private BirdLevelData _birdLevelData;
        [SerializeField] private Transform _container;
        [SerializeField] private int _roundTimeSeconds = 30;

        
        public override void InstallBindings()
        {
            if (!CheckAndLogDependencies())
                return;
            
            Container.DeclareSignal<CandyCollectedSignal>();
            Container.DeclareSignal<LevelSelectedSignal>();
            Container.DeclareSignal<OnHitSignal>();
            
            Container.Bind<PauseManager>().ToSelf().AsSingle();
            Container.Bind<ResultPopup>().FromInstance(_resultPopup);
            Container.Bind<TopPanel>().FromInstance(_topPanel);
          
            Container.Bind<string>().WithId("TimerStringFormat").FromInstance(_timerUiFormat).AsSingle();
            Container.BindInterfacesAndSelfTo<VolkCore.Game.Timer>().FromNew().AsSingle();
            Container.Bind<TimeSpan>().FromInstance(new TimeSpan(0,0,_roundTimeSeconds)).AsCached();

            Container.Bind<ALevelFactory<LevelData>>().To<BirdLevelFactory>().FromScriptableObject(_levelFactory).AsSingle();
            Container.BindInterfacesAndSelfTo<Bird>().FromInstance(_bird);
            Container.Bind(typeof(AGameLevels<LevelData>),typeof(IInitializable)
                ,typeof(ILevelProgress),typeof(IDisposable)).To<BirdLevels>().AsSingle();

            Container.BindMemoryPool<Spike, SpikePool>()
                .WithInitialSize(10)
                .FromComponentInNewPrefab(_spikePrefab)
                .UnderTransform(_container);
            
            Container.BindMemoryPool<Candy, CandyPool>()
                .WithInitialSize(2)
                .FromComponentInNewPrefab(_candyPrefab)
                .UnderTransform(_container);
            
            Container.Bind<BirdLevelData>().ToSelf().FromInstance(_birdLevelData).AsSingle().NonLazy();
            Container.Bind<BirdLevelBuilder>().ToSelf().AsSingle();
            Container.Bind<BirdData>().ToSelf().AsSingle();
            Container.BindInterfacesAndSelfTo<BirdGame>().FromNew().AsSingle();
        }
    }


}