using VolkCore.Collections;

namespace VolkBird
{
    public interface IHittable
    {
        public void Hit(IItem damager);
    }
}