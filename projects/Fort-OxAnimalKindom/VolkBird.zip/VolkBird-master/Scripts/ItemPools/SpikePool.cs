﻿using VolkCore.Game;

namespace VolkBird.ItemPools
{
    public class SpikePool : BaseMonoPool<Spike> { }
}