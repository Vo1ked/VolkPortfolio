﻿using VolkCore.Game;

namespace VolkBird.ItemPools
{
    public class CandyPool : BaseMonoPool<Candy> { }
}