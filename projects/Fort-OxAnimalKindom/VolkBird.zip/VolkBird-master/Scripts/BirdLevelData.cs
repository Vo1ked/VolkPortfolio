using UnityEngine;
using VolkBird.Save;
using VolkCore.Save;
using Zenject;

namespace VolkBird
{
    [System.Serializable]
    public class BirdLevelData
    {
        [SerializeField] public GameObject BottomSpikes;
        [SerializeField] public Transform LeftWall;
        [SerializeField] public Transform RightWall;
        [SerializeField] public Transform Container;
        [SerializeField] public float Offset;
        
    }
}