﻿using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using VolkBird.Save;
using VolkCore.Game;

namespace VolkBird
{
    [CreateAssetMenu(fileName = "BirdLevelFactory", menuName = "Inventory/Bird Level Factory", order = 0)]
    public class BirdLevelFactory : ALevelFactory<LevelData>
    {
        [SerializeField] private int _levelCount = 28;
        [SerializeField] private int _maxSpikes = 5;
        [SerializeField] private int _maxCandies = 8;

        [SerializeField] private float _spikeWidth = 0.05f;
        [SerializeField] private float _spikeHeight = 0.05f;
        [SerializeField] private float _candyWidth = 0.05f;
        [SerializeField] private float _candyHeight = 0.05f;
        [SerializeField] private float _minPosition = 0.05f;
        [SerializeField] private float _maxPosition = 0.95f;

        public override LevelData[] GenerateLevels()
        {
            var levels = new List<LevelData>();

            var currentSide = SpikePosition.SpikeSide.Left;

            for (int level = 1; level <= _levelCount; level++)
            {
                int maxSpikesForLevel = Mathf.CeilToInt((_maxSpikes / (float)_levelCount) * level);
                int maxCandiesForLevel = Mathf.CeilToInt((_maxCandies / (float)_levelCount) * level);

                int candyCount = Random.Range(
                    Mathf.Max(1, maxCandiesForLevel - _maxCandies / 2),
                    Mathf.Min(_maxCandies, maxCandiesForLevel + _maxCandies / 2) + 1
                );

                var candiesPositions = GenerateCandies(candyCount, currentSide);
                var spikes = new List<SpikePosition>();

                for (int i = 0; i < candyCount; i++)
                {
                    int spikeCount = Random.Range(
                        Mathf.Max(0, maxSpikesForLevel - _maxSpikes / 2),
                        Mathf.Min(_maxSpikes, maxSpikesForLevel + _maxSpikes / 2) + 1
                    );

                    var spikesForRound = GenerateSpikes(spikeCount, i + 1, currentSide, candiesPositions[i]);
                    spikes.AddRange(spikesForRound);

                    currentSide = currentSide == SpikePosition.SpikeSide.Left ? SpikePosition.SpikeSide.Right : SpikePosition.SpikeSide.Left;
                }

                var levelData = new LevelData
                {
                    Level = level,
                    CandiesCount = candyCount,
                    CandiesPositions = candiesPositions.ToArray(),
                    Spikes = spikes.ToArray()
                };

                levels.Add(levelData);
            }

            return levels.ToArray();
        }

        private List<Vector2> GenerateCandies(int candyCount, SpikePosition.SpikeSide startingSide)
        {
            var candies = new List<Vector2>();

            SpikePosition.SpikeSide currentSide = startingSide;

            for (int i = 0; i < candyCount; i++)
            {
                Vector2 position;
                float minX = currentSide == SpikePosition.SpikeSide.Left ? 0f : 0.5f;
                float maxX = currentSide == SpikePosition.SpikeSide.Left ? 0.5f : 1f;
                
                    float xPosition = Random.Range(minX + _candyWidth / 2, maxX - _candyWidth / 2);
                    float yPosition = Random.Range(_minPosition + _candyHeight / 2, _maxPosition - _candyHeight / 2);
                    position = new Vector2(xPosition, yPosition);
                    
                candies.Add(position);
                currentSide = currentSide == SpikePosition.SpikeSide.Left ? SpikePosition.SpikeSide.Right : SpikePosition.SpikeSide.Left;
            }

            return candies;
        }

        private List<SpikePosition> GenerateSpikes(int spikeCount, int round, SpikePosition.SpikeSide side, Vector2 candyPosition)
        {
            var spikes = new List<SpikePosition>();
            var usedRects = new List<Rect>();

            usedRects.Add(new Rect(
                candyPosition.x - _candyWidth / 2,
                candyPosition.y - _candyHeight / 2,
                _candyWidth,
                _candyHeight
            ));

            float spikeX = side == SpikePosition.SpikeSide.Left ? 0f : 1f;

            for (int i = 0; i < spikeCount; i++)
            {
                float yPosition;
                int attempts = 0;
                do
                {
                    yPosition = Random.Range(_minPosition + _spikeHeight / 2, _maxPosition - _spikeHeight / 2);
                    attempts++;

                    Rect spikeRect = new Rect(
                        spikeX - _spikeWidth / 2,
                        yPosition - _spikeHeight / 2,
                        _spikeWidth,
                        _spikeHeight
                    );

                    if (!IsOverlapping(spikeRect, usedRects))
                    {
                        usedRects.Add(spikeRect);
                        spikes.Add(new SpikePosition
                        {
                            Side = side,
                            Position = yPosition,
                            Round = round
                        });
                        break;
                    }

                } while (attempts < 100);

                if (attempts >= 100)
                {
                    Debug.LogWarning("Не удалось найти позицию для шипа без пересечений.");
                }
            }

            return spikes;
        }

        private bool IsOverlapping(Rect rect, List<Rect> usedRects)
        {
            return usedRects.Any(rect.Overlaps);
        }
    }
}
