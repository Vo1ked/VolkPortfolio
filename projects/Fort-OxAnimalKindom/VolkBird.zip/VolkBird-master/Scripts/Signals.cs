using VolkCore.Collections;

namespace VolkBird.Signals
{
    public struct CandyCollectedSignal { }

    public struct OnHitSignal
    {
        public readonly Bird Bird;
        public readonly IItem Item;

        public OnHitSignal(Bird bird, IItem item)
        {
            Bird = bird;
            Item = item;
        }
        
    }
}