﻿using UnityEngine;
using VolkCore.Collections;

namespace VolkBird
{
    public class Spike : MonoBehaviour, IItem
    {
        private void OnTriggerEnter2D(Collider2D other) => other.gameObject.GetComponent<IHittable>()?.Hit(this);
    }
}