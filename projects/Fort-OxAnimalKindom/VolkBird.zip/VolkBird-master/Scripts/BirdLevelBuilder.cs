﻿using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using VolkBird.ItemPools;
using VolkBird.Save;
using VolkCore.Game;
using VolkCore.Save;

namespace VolkBird
{
    public class BirdLevelBuilder
    {
        private readonly BirdLevelData _data;
        private readonly SpikePool _spikePool;
        private readonly CandyPool _candyPool;
        private readonly AGameLevels<LevelData> _levels;
        private readonly List<Spike> _spikes = new List<Spike>();
        
        private Candy _candy;
        
        public BirdLevelBuilder(
            BirdLevelData data,
            SpikePool spikePool,
            CandyPool candyPool,
            AGameLevels<LevelData> levels)
        {
            _data = data;
            _spikePool = spikePool;
            _candyPool = candyPool;
            _levels = levels;

            _data.LeftWall.position =
                Camera.main.ViewportToWorldPoint(new Vector3(0, 0, Camera.main.nearClipPlane + 1f))
                - Vector3.right * 0.5f;
            _data.RightWall.position =
                Camera.main.ViewportToWorldPoint(new Vector3(1, 0, Camera.main.nearClipPlane + 1f))
                + Vector3.right * 0.5f;
        }

        public void BuildLevel(int round)
        {
            var levelData = _levels.CurrentLevel;
            ClearLevel();
            _data.BottomSpikes.SetActive(true);

            if (round < 0 || round >= levelData.CandiesPositions.Length)
            {
                Debug.LogWarning($"Round {round} out of levels dictionary");
                return;
            }

            Vector2 candyPos = Camera.main.ViewportToWorldPoint(levelData.CandiesPositions[round]);
            _candy = _candyPool.Spawn(new PrefabData(candyPos, Quaternion.identity, _data.Container));

            foreach (var spike in levelData.Spikes.Where(s=>s.Round == round))
            {
                float xNorm = spike.Side == SpikePosition.SpikeSide.Left ? 0f : 1f;
                float xOffset = spike.Side == SpikePosition.SpikeSide.Left ? _data.Offset : -_data.Offset;

                Vector2 viewPos = new Vector2(xNorm, spike.Position);
                Vector2 worldPos = Camera.main.ViewportToWorldPoint(viewPos);
                worldPos.x += xOffset;

                Quaternion rot = spike.Side == SpikePosition.SpikeSide.Left
                    ? Quaternion.Euler(0, 180, 0)
                    : Quaternion.identity;
                var spikeInstance = _spikePool.Spawn(new PrefabData(worldPos, rot, _data.Container));
                _spikes.Add(spikeInstance);
            }
        }

        private void ClearLevel()
        {
            _spikes.ForEach(s=>_spikePool.Despawn(s));
            _spikes.Clear();

            if (_candy != null)
            {
                _candyPool.Despawn(_candy);
                _candy = null;
            }
        }

    }
}
