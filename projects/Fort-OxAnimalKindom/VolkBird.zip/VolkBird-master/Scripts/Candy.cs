﻿using UnityEngine;
using VolkBird.Signals;
using Zenject;

namespace VolkBird
{
    public class Candy : MonoBehaviour
    {
        [Inject] private SignalBus _signalBus;
        private void OnTriggerEnter2D(Collider2D other) => _signalBus.Fire<CandyCollectedSignal>();
    }
}