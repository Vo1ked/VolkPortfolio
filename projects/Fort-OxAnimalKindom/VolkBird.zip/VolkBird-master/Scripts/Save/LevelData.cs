﻿using System;
using UnityEngine;

namespace VolkBird.Save
{
    [Serializable]
    public struct LevelData
    {
        public int Level;
        public int CandiesCount;
        public Vector2[] CandiesPositions;
        public SpikePosition[] Spikes;
    }

    [Serializable]
    public struct SpikePosition
    {
        public SpikeSide Side;
        public float Position;
        public int Round;
        public enum SpikeSide
        {
            Left = 0,
            Right = 1
        }
    }
}