﻿using VolkBird.Save;
using VolkCore.Save;

namespace VolkBird.Collections
{
    public class BirdLevels : AGameLevels<LevelData>
    {
        protected override string GameName => "HeavenlyBird";
    }
}