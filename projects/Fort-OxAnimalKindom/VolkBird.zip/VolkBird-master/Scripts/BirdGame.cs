﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using UnityEngine;
using VolkBird.Signals;
using VolkCore.Game;
using VolkCore.Signals;
using VolkCore.Tools;
using Zenject;

namespace VolkBird
{
    public class BirdGame : IInitializable, IDisposable, IGameProgress
    {
        public Action OnInited { get; set; }
        public bool Inited { get; private set; }
        public IReadOnlyDictionary<int, IGoalProgress> GameProgress=>_gameProgress.ToDictionary(
            keyValuePair=>keyValuePair.Key,
            keyValuePair=>(IGoalProgress)keyValuePair.Value);

        public event Action<IReadOnlyDictionary<int, IGoalProgress>> OnChanged;
        
        [Inject] private TimeSpan _roundTime;
        private readonly CancellationTokenSource _cancellationTokenSource;
        private readonly BirdData _data;

        private Dictionary<int, GoalProgress> _gameProgress;

        public BirdGame(BirdData birdData)
        {
            _data = birdData;
            _cancellationTokenSource = new CancellationTokenSource();
        }

        public void Initialize()
        {
            _data.Timer.TimerEnd += ShowLosePopup;
            _data.SignalBus.Subscribe<LevelSelectedSignal>(StartGame);
            _data.SignalBus.Subscribe<CandyCollectedSignal>(CandyCollected);
            _data.SignalBus.Subscribe<OnHitSignal>(OnHit);
            _ = InitAsync();
        }

        private async Awaitable InitAsync()
        {
            await _data.Levels;
            _gameProgress = new Dictionary<int, GoalProgress>
            {
                {
                    0, new GoalProgress(new ReactiveVariable<int>(0), new ReactiveVariable<float>(0),
                        new ReactiveVariable<float>(_data.Levels.CurrentLevel.CandiesCount))
                }
            };
            OnChanged?.Invoke(GameProgress);
            Inited = true;
            OnInited?.Invoke();
        }
        
        public InitAwaiter GetAwaiter() => new InitAwaiter(this);

        private void CandyCollected()
        {
            _gameProgress[0].CurrentValue.Value++;
            OnChanged?.Invoke(GameProgress);
            if (_gameProgress[0].Current.Value >= _gameProgress[0].Max.Value)
            {
                ShowWinPopup();
                return;
            }

            _data.LevelBuilder.BuildLevel((int)_gameProgress[0].Current.Value);
        }

        private void OnGameEnd()
        {
            _data.Timer.StopTimer();
            _data.Bird.StopGame();
        }

        private void ShowWinPopup()
        {
            OnGameEnd();
            _data.Levels.IncrementLevel();
            _data.Balance.Balance.Value += 200;
            _data.ResultPopup.OnRetry += StartNextLevel;
            _ = _data.ResultPopup.SetWin(200, -1, _cancellationTokenSource.Token);

        }

        private void ShowLosePopup()
        {
            OnGameEnd();
            _data.Balance.Balance.Value -= 100;
            _data.ResultPopup.OnRetry += RetryLevel;
            _ = _data.ResultPopup.SetLose(100, -1, _cancellationTokenSource.Token);
        }

        private void RetryLevel()
        {
            _data.ResultPopup.OnRetry -= RetryLevel;
            StartGame();
        }

        private void StartNextLevel()
        {
            _data.ResultPopup.OnRetry -= StartNextLevel;
            _data.Levels.SelectLevel(_data.Levels.CurrentLevelId.Value + 1);
            StartGame();
        }

        private void StartGame()
        {
            _data.LevelBuilder.BuildLevel(0);
            _data.Bird.StartGame();
            _gameProgress[0].CurrentValue.Value = 0;
            _gameProgress[0].MaxValue.Value = _data.Levels.CurrentLevel.CandiesCount;
            OnChanged?.Invoke(GameProgress);
            _data.Timer.Initialize(_roundTime);
            _data.Timer.StartTimer();
        }

        private void OnHit(OnHitSignal onHitSignal)
        {
            _data.Timer.StopTimer();
            onHitSignal.Bird.StopGame();
            ShowLosePopup();
        }

        public void Dispose()
        {
            _data.SignalBus.Unsubscribe<CandyCollectedSignal>(CandyCollected);
            _data.SignalBus.Unsubscribe<LevelSelectedSignal>(StartGame);
            _data.SignalBus.Unsubscribe<OnHitSignal>(OnHit);
        }
    }
}