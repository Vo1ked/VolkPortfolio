﻿using UnityEngine;
using VolkBird.Signals;
using VolkCore.Collections;
using VolkInput;
using Zenject;

namespace VolkBird
{
    public class Bird : MonoBehaviour, IPausable,IHittable
    {
        [SerializeField] private Rigidbody2D _rigidbody;
        [SerializeField] private Animator _animator;
        [SerializeField] private float _jumpForce = 5f;
        [SerializeField] private float _sideForce = 2f;

        [Inject] private IVolkInput _volkInput;
        [Inject] private SignalBus _signalBus;
        private bool _isPaused;
        private bool _isRunning;

        private static readonly int Fly = Animator.StringToHash("Fly");

        private void Awake()
        {
            _rigidbody.bodyType = RigidbodyType2D.Static;
            _isRunning = false;
            _volkInput.OnPressStart += Jump;
        }

        private void OnDestroy()
        {
            _volkInput.OnPressStart -= Jump;
        }

        private void Jump(Vector2 inputPosition)
        {
            if (_isPaused || !_isRunning)
                return;

            Vector2 direction = Vector2.up * _jumpForce;

            var screenMiddle = Screen.safeArea.width / 2 + Screen.safeArea.x;

            if (inputPosition.x < screenMiddle)
            {
                direction += Vector2.left * _sideForce;
                transform.localScale = new Vector3(-1, 1, 1);
            }
            else
            {
                direction += Vector2.right * _sideForce;
                transform.localScale = new Vector3(1, 1, 1);
            }

            _animator.SetTrigger(Fly);
            _rigidbody.linearVelocity = Vector2.zero;
            _rigidbody.AddForce(direction, ForceMode2D.Impulse);
        }

        public void StartGame()
        {
            _rigidbody.bodyType = RigidbodyType2D.Dynamic;

            _rigidbody.linearVelocity = Vector2.zero;
            transform.position = Vector2.zero;
            _isRunning = true;
        }

        public void StopGame()
        {
            _rigidbody.bodyType = RigidbodyType2D.Static;
            _isRunning = false;
        }

        public void OnPause()
        {
            _isPaused = true;
            _rigidbody.bodyType = RigidbodyType2D.Static;
            Debug.Log($"Pause: {_isPaused}");
        }

        public void OnResume()
        {
            _isPaused = false;
            _rigidbody.bodyType = RigidbodyType2D.Dynamic;
        }

        public void Hit(IItem damager)
        {
            _signalBus.Fire(new OnHitSignal(this, damager));
        }
    }
}
