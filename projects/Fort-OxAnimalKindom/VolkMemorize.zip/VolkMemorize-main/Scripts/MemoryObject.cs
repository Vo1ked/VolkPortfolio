﻿using UnityEngine;
using UnityEngine.UI;
using VolkMemorize.Signals;
using Zenject;

namespace VolkMemorize
{
    public class MemoryObject : MonoBehaviour
    {
        public int Position => _position;
        
        [SerializeField] private Image _image;
        [SerializeField] private Button _button;
        [SerializeField] private int _position;
        [SerializeField] private GameObject _view;
        
        [Inject] SignalBus _signalBus;
        public void Awake()
        {
            _button.onClick.AddListener(AtClick);
        }

        public void Setup(Sprite image)
        {
            _image.sprite = image;
            _button.interactable = false;
        }

        public void SetButtonInteraction(bool enable)
        {
            _button.interactable = enable;
        }

        public void Show()
        {
            _view.SetActive(false);
        }

        public void Hide()
        {
            _view.SetActive(true);
        }

        private void AtClick()
        {
            _signalBus.Fire(new MemoryObjectSelectedSignal(this));
        }
        
        public void Disable()
        {
            gameObject.SetActive(false);
            _button.onClick.RemoveListener(AtClick);
        }
        
    }
}