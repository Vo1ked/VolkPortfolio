namespace VolkMemorize.Signals
{
    public struct MemoryObjectSelectedSignal
    {
        public readonly MemoryObject MemoryObject;

        public MemoryObjectSelectedSignal(MemoryObject memoryObject)
        {
            MemoryObject = memoryObject;
        }
    }
}