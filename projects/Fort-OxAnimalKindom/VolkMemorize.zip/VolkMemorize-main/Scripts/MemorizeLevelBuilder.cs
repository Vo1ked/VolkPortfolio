﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using UnityEngine;
using VolkMemorize.Signals;
using Zenject;

namespace VolkMemorize
{
    public class MemorizeLevelBuilder : IDisposable
    {
        private readonly SignalBus _signalBus;
        private readonly float _showTime;
        private readonly MemoryObject[] _memoryObjects;
        private readonly CancellationTokenSource _cts;

        private LevelData _currentLevel;

        public MemorizeLevelBuilder([Inject(Id = "MemoryObjects")] MemoryObject[]
            memoryObjects, [Inject(Id = "ShowTime")] float showTime, SignalBus signalBus)
        {
            _showTime = showTime;
            _memoryObjects = memoryObjects;
            _signalBus = signalBus;
            _cts = new CancellationTokenSource();

            _signalBus.Subscribe<MemoryObjectSelectedSignal>(OnClick);
        }
        
        public async Task StartGame(LevelData levelData)
        {
            _currentLevel = levelData;
            var memorizeItems = new Dictionary<int, MemoryObject>();
            foreach (var memoryObject in _memoryObjects)
            {
                if (_currentLevel.ItemCount > memoryObject.Position)
                {
                    memoryObject.Hide();
                    memoryObject.Setup(_currentLevel.Sprites[memoryObject.Position]);
                    memorizeItems.Add(memoryObject.Position, memoryObject);
                }
                else
                {
                    memoryObject.Disable();
                }
            }

            await ShowSequence(_currentLevel, memorizeItems);
            foreach (var items in memorizeItems.Values)
            {
                items.Hide();
                items.SetButtonInteraction(true);
            }
        }

        private void OnClick(MemoryObjectSelectedSignal memoryObjectSelectedSignal)
        {
            var item = memoryObjectSelectedSignal.MemoryObject;
            item.Show();
            item.SetButtonInteraction(false);
        }

        private async Task ShowSequence(LevelData currentLevel, Dictionary<int, MemoryObject> memorizeItems)
        {
            foreach (int position in currentLevel.Sequence)
            {
                try
                {
                    memorizeItems[position].Show();
                    await Awaitable.WaitForSecondsAsync(_showTime, _cts.Token);
                }
                catch (OperationCanceledException) { }
            }
        }

        public void Dispose()
        {
            _cts.Cancel();
            _cts.Dispose();
            _signalBus.Unsubscribe<MemoryObjectSelectedSignal>(OnClick);
        }
    }
}