﻿using System;
using Save;
using UnityEngine;
using VolkCore.Collections;
using VolkCore.Game;
using VolkCore.Save;
using VolkCore.SceneManagement;
using VolkCore.Signals;
using VolkCore.UI;
using VolkMemorize.Signals;
using Zenject;

namespace VolkMemorize
{
    public class MemorizeSceneInstaller : ASceneInstaller
    {
        [SerializeField] private TopPanel _topPanel;
        [SerializeField] public ResultPopup _resultPopup;
        [SerializeField] private string _timerUiFormat = "TIME: {0}";
        [Space]
        [SerializeField] public Sprite[] _memorizeSprites;
        [SerializeField] private MemoryObject[] _memoryObjects;
        [SerializeField] private MemorizeLevelFactory _memorizeLevelFactory;
        [Space]
        [SerializeField] private float _showTime = 0.5f;
        [SerializeField] private int _roundTimeSeconds = 10;

        public override void InstallBindings()
        {
            if (!CheckAndLogDependencies())
                return;
            Container.BindInterfacesAndSelfTo<Timer>().FromNew().AsSingle();
            Container.Bind<string>().WithId("TimerStringFormat").FromInstance(_timerUiFormat).AsCached();
            Container.Bind<MemoryObject[]>().WithId("MemoryObjects").FromInstance(_memoryObjects).AsCached();
            Container.Bind<Sprite[]>().WithId("MemorizeSprites").FromInstance(_memorizeSprites).AsCached();
            Container.Bind<float>().WithId("ShowTime").FromInstance(_showTime).AsCached();
            Container.Bind<TimeSpan>().FromInstance(new TimeSpan(0,0,_roundTimeSeconds)).AsCached();
            Container.Bind<TopPanel>().FromInstance(_topPanel).AsSingle();
            Container.Bind<ResultPopup>().FromInstance(_resultPopup).AsSingle();

            Container.Bind<ALevelFactory<LevelData>>().To<MemorizeLevelFactory>()
                .FromScriptableObject(_memorizeLevelFactory).AsSingle();

            Container.Bind(typeof(AGameLevels<LevelData>),typeof(IInitializable),typeof(IDisposable)
                    ,typeof(ILevelProgress))
                .To<MemorizeLevels>().AsSingle();
            Container.Bind(typeof(IDisposable) ,typeof(MemorizeLevelBuilder))
                .To<MemorizeLevelBuilder>().FromNew().AsSingle();
            Container.Bind(typeof(IInitializable),typeof(IDisposable),typeof(IGameProgress))
                .To<Memorize>().FromNew().AsSingle();
            Container.Bind<PauseManager>().ToSelf().AsSingle();

            Container.DeclareSignal<LevelSelectedSignal>();
            Container.DeclareSignal<MemoryObjectSelectedSignal>();
        }
    }
}