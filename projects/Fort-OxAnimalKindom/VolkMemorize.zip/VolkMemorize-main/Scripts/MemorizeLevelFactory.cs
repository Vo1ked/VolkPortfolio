﻿using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using VolkCore.Game;

namespace VolkMemorize
{
    [CreateAssetMenu(fileName = "MemorizeLevelFactory", menuName = "Volk/Memorize/Memorize Level Factory")]
    public class MemorizeLevelFactory : ALevelFactory<LevelData>
    {
        [SerializeField] private int levelCount = 28;
        [SerializeField] private int minIcons = 3;
        [SerializeField] private int maxIcons = 6;
        [SerializeField] private Sprite[] _sprites;

        public override LevelData[] GenerateLevels()
        {
            var levels = new List<LevelData>();
            float step = (float)(maxIcons - minIcons) / (levelCount - 1);
            for (int level = 0; level < levelCount; level++)
            {
                int itemCount = Mathf.RoundToInt(minIcons + step * level);
                int[] spriteIds = GetRandomSpriteIds(itemCount);
                int[] sequence = Enumerable.Range(0, itemCount).OrderBy(x => Random.value).ToArray();
                levels.Add(new LevelData(level, itemCount, spriteIds, sequence));
            }

            return levels.ToArray();
        }

        private int[] GetRandomSpriteIds(int count)
        {
            List<int> availableIndices = Enumerable.Range(0, _sprites.Length).ToList();
            int[] selectedSpriteIds = new int[count];
            for (int i = 0; i < count; i++)
            {
                int index = Random.Range(0, availableIndices.Count);
                selectedSpriteIds[i] = availableIndices[index];
                availableIndices.RemoveAt(index);
            }
            return selectedSpriteIds;
        }

        public Sprite GetSpriteById(int id)
        {
            if (id >= 0 && id < _sprites.Length)
            {
                return _sprites[id];
            }
            return null;
        }
    }
}