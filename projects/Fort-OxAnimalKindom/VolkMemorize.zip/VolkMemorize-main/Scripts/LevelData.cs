﻿using System;
using UnityEngine;

namespace VolkMemorize
{
    [Serializable]
    public struct LevelData
    {
        public int Level ;
        public int ItemCount;
        public int[] SpriteIds;
        public int[] Sequence;
        [NonSerialized]
        public Sprite[] Sprites;

        public LevelData(int level, int itemCount, int[] sprites, int[] sequence)
        {
            Level = level;
            ItemCount = itemCount;
            SpriteIds = sprites;
            Sequence = sequence;
            Sprites = null;
        }

        public void SetSprites(Sprite[] sprites)
        {
            Sprites = new Sprite[sprites.Length];
            Sprites = sprites;
        }
    }
}