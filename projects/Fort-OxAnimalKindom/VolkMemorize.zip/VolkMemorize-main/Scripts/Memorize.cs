﻿using System;
using System.Collections.Generic;
using System.Linq;
using VolkCore.Signals;
using Zenject;
using System.Threading;
using VolkCore.Game;
using VolkCore.Save;
using VolkCore.SceneManagement.UI;
using VolkCore.Tools;
using VolkCore.UI;
using VolkMemorize.Signals;
using Timer = VolkCore.Game.Timer;

namespace VolkMemorize
{
    public class Memorize : IInitializable, IDisposable, IGameProgress
    {
        public Action OnInited { get; set; }
        public bool Inited { get; private set; }
        public IReadOnlyDictionary<int, IGoalProgress> GameProgress => _gameProgress.ToDictionary(
            keyValuePair=>keyValuePair.Key,
            keyValuePair=>(IGoalProgress)keyValuePair.Value);
        public event Action<IReadOnlyDictionary<int, IGoalProgress>> OnChanged;

        [Inject] public ResultPopup _resultPopup;
        [Inject] public ILoadingScreen _loadingScreen;
        [Inject] public AGameLevels<LevelData> _levelsData;
        [Inject] public MemorizeLevelBuilder _levelBuilder;
        [Inject] public SignalBus _signalBus;
        [Inject] private Timer _timer;
        [Inject] private TimeSpan _roundTime;
        [InjectOptional] public IBet _bet;
        [InjectOptional] public IBalance _balance;
        
        private  Dictionary<int, GoalProgress> _gameProgress;
        private CancellationTokenSource _cts = new CancellationTokenSource();
        private int _selectedBet;
        private bool _gameStarted = false;
        private MemoryObject _lastMemoryObject;

        public async void Initialize()
        {
            await _levelsData;
            _gameProgress = new Dictionary<int, GoalProgress>
            {
                {0,new GoalProgress(new ReactiveVariable<int>(0),new ReactiveVariable<float>(0),
                    new ReactiveVariable<float>(_levelsData.CurrentLevel.ItemCount))}
            };
            Inited = true;
            OnInited?.Invoke();
            _signalBus.Subscribe<LevelSelectedSignal>(StartGame);
            _signalBus.Subscribe<MemoryObjectSelectedSignal>(MemoryObjectSelected);
            
            _timer.TimerEnd += ShowLose;
            _resultPopup.OnRetry += StartGame;
            _loadingScreen.TryHide();
            OnChanged?.Invoke(GameProgress);
        }

        public InitAwaiter GetAwaiter() => new InitAwaiter(this);

        private void MemoryObjectSelected(MemoryObjectSelectedSignal memoryObjectSelectedSignal)
        {
            _gameStarted = false;
            _lastMemoryObject = memoryObjectSelectedSignal.MemoryObject;
            if (_levelsData.CurrentLevel.Sequence[(int)GameProgress[0].Current.Value] == _lastMemoryObject.Position)
            {
                _gameProgress[0].CurrentValue.Value++;
                OnChanged?.Invoke(GameProgress);
                
                if ((int)GameProgress[0].Current.Value  != (int)GameProgress[0].Max.Value)
                    return;

                ShowWin();
            }
            else
            {
                ShowLose();
            }
        }

        private void ShowLose()
        {
            if (_balance != null) 
                _balance.Balance.Value -= _bet.CurrentBet;
            _timer.StopTimer();
            _ = _resultPopup.SetLose(_selectedBet, -1, _cts.Token);
        }

        private void ShowWin()
        {
            _timer.StopTimer();
            _levelsData.IncrementLevel();
            _levelsData.SelectLevel(_levelsData.CurrentLevelId.Value + 1);
            if (_balance != null) 
                _balance.Balance.Value += _selectedBet * 2;
            _ = _resultPopup.SetWin(_selectedBet, -1, _cts.Token);
        }

        private async void StartGame()
        {
            if (_gameStarted)
                return;

            _cts.Cancel();
            _cts.Dispose();
            _cts = new CancellationTokenSource();
            _timer.Initialize(_roundTime);
            _gameProgress[0].CurrentValue.Value = 0;
            _gameProgress[0].MaxValue.Value = _levelsData.CurrentLevel.ItemCount;
            OnChanged?.Invoke(GameProgress);
            if (_balance != null)
            {
                if (_balance.Balance.Value < _bet.CurrentBet)
                    return;
                _selectedBet = _bet.CurrentBet;
            }
            
            _gameStarted = true;

            await _levelBuilder.StartGame(_levelsData.CurrentLevel);
            _timer.StartTimer();
        }
        

        public void Dispose()
        {
            _cts.Cancel();
            _cts.Dispose();
            
            _signalBus.Unsubscribe<LevelSelectedSignal>(StartGame);
            _signalBus.Unsubscribe<MemoryObjectSelectedSignal>(MemoryObjectSelected);
            
            _resultPopup.OnRetry -= StartGame;
        }
    }
}