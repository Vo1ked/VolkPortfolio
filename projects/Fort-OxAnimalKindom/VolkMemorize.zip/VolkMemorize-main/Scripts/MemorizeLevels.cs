﻿using System;
using Save;
using UnityEngine;
using VolkCore.Save;
using Zenject;

namespace VolkMemorize
 {
     public class MemorizeLevels : AGameLevels<LevelData>
     {
         protected override string GameName => "Memorize";

         protected override async Awaitable LoadLevels()
         {
             await base.LoadLevels();
             
             for (var i = 0; i < Levels.Length; i++)
             {
                 SetSpritesForLevel(ref Levels[i]);
             }
         }
         
         private void SetSpritesForLevel(ref LevelData level)
         {
             var sprites = new Sprite[level.SpriteIds.Length];
             var memorizeFactory = (MemorizeLevelFactory)LevelFactory;
             for (int i = 0; i < level.SpriteIds.Length; i++)
             {
                 sprites[i] = memorizeFactory.GetSpriteById(level.SpriteIds[i]);
             }
             
             level.SetSprites(sprites);
         }
     }
 }