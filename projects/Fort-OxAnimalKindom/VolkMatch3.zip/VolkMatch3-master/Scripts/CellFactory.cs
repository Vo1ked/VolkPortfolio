﻿using System;
using VolkCore.Collections;
using UnityEngine;
using VolkCore.Game;
using VolkMatch3.Collections;
using VolkMatch3.ItemPools;
using Zenject;

namespace VolkMatch3
{
    public class CellFactory
    {
        [Inject] private ItemsCollection<CellData> _cellItems;
        [Inject] private CellPool<Cell> _cellPool;
        [Inject] private BombCellPool _bombCellPool;
        [Inject] private CellsGrid _grid;
        private int _tries = 0;
        private CheckAvailableMoves _checkAvailableMoves;

        public void GenerateGrid(LevelData levelData)
        {
            _tries = 0;
            _checkAvailableMoves = new CheckAvailableMoves();
            var container = (RectTransform)_grid.Container;
            container.sizeDelta = new Vector2(levelData.Size.x * levelData.CellSize.x, levelData.Size.y * levelData.CellSize.y);

            GenerateCells(levelData);
        }

        private void GenerateCells(LevelData levelData)
        {
            if (_grid.Grid?.Length > 0)
            {
                foreach (Cell cell in _grid.Grid)
                {
                    if (cell != null)
                    {
                        Despawn(cell);
                    }
                }
            }
            _grid.Grid = new Cell[levelData.Size.x, levelData.Size.y];

            for (int x = 0; x < levelData.Size.x; x++)
            {
                for (int y = 0; y < levelData.Size.y; y++)
                {
                    var cell = SpawnRandomCell(x, y, levelData);
                    _grid.Grid[x, y] = cell;
                }
            }
            while (_checkAvailableMoves.HasAnyCombo(_grid.Grid, out var combination) && _tries < 100)
            {
                _tries++;
                foreach (var cell in combination)
                {
                    var newCell = SpawnRandomCell(cell.GridPosition.x, cell.GridPosition.y, levelData);
                    _grid.Grid[cell.GridPosition.x, cell.GridPosition.y] = newCell;
                    Despawn(cell);
                }
            }

            if (!_checkAvailableMoves.HasMoves(_grid.Grid) && _tries < 100)
            {
                _tries++;
                GenerateCells(levelData);
            }
        }

        public void Despawn(Cell cell)
        {
            switch (cell.Id)
            {
                case CellType.Green:
                case CellType.Red:
                case CellType.Purple:
                case CellType.Blue:
                    _cellPool.Despawn(cell);
                    break;
                case CellType.Bomb:
                    _bombCellPool.Despawn((BombCell)cell);
                    break;
                case CellType.None:
                default:
                    throw new ArgumentOutOfRangeException();
            }
        }

        private Cell Spawn(CellData cellData, PrefabData prefabData)
        {
            Cell cell;
            switch (cellData.Id)
            {
                case CellType.Green:
                case CellType.Red:
                case CellType.Purple:
                case CellType.Blue:
                    cell = _cellPool.Spawn(cellData,prefabData);
                    break;
                case CellType.Bomb:
                    cell = _bombCellPool.Spawn(cellData,prefabData);
                    break;
                case CellType.None:
                default:
                    throw new ArgumentOutOfRangeException();
            }

            return cell;
        }

        public Cell SpawnRandomCell(int x, int y, LevelData levelData)
        {
            var randomCell = _cellItems.GetRandomItem();
            var cellData = new CellData(randomCell.Id, randomCell.Sprite, new Vector2Int(x, y), levelData.CellSize);
            float offsetX = -levelData.Size.x * levelData.CellSize.x / 2 + levelData.CellSize.x / 2;
            float offsetY = levelData.Size.y * levelData.CellSize.y / 2 - levelData.CellSize.y / 2;
            float posX = x * levelData.CellSize.x + offsetX;
            float posY = -y * levelData.CellSize.y + offsetY;
            
            var newItem = Spawn(cellData, new PrefabData(new Vector3(posX, posY, 0), Quaternion.identity, _grid.Container));
            if (newItem == null)
            {
                Debug.LogError($"Failed to spawn cell at ({x}, {y})");
            }

            return newItem;
        }
    }
}