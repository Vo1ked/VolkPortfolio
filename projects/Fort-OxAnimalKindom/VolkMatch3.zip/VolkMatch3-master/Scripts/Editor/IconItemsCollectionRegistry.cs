﻿using VolkMatch3.Collections;

namespace VolkMatch3.Editor
{
    public class IconItemsCollectionRegistry
    {
        [UnityEditor.InitializeOnLoadMethod]
        private static void Register()
        {
            ItemsCollectionEditorWindow.RegisterCollectionType(typeof(CellItemCollection));
        }
    }
}