﻿using UnityEditor;
using UnityEngine;
using VolkCore.Save;
using VolkMatch3.Collections;
using Zenject;

namespace VolkMatch3.Editor
{
    public class DrawGrid : MonoBehaviour
    {
        [Inject] private CellsGrid _grid;
        [Inject] private AGameLevels<LevelData> _levels;
        [SerializeField] private bool canDraft = false;

        private void Update()
        {
            if (Input.GetKeyDown(KeyCode.H))
            {
                canDraft = !canDraft;
            }
        }

        private void ShowGrid()
        {
            var levelData = _levels.CurrentLevel;
            for (var x = 0; x < _grid.Grid.GetLength(0); x++)
            for (var y = 0; y < _grid.Grid.GetLength(1); y++)
            {
                var cell = _grid.Grid[x, y];
                float offsetX = -levelData.Size.x * levelData.CellSize.x / 2 + levelData.CellSize.x / 2;
                float offsetY = levelData.Size.y * levelData.CellSize.y / 2 - levelData.CellSize.y / 2;
                float posX = x * levelData.CellSize.x + offsetX;
                float posY = -y * levelData.CellSize.y + offsetY;
                if (cell != null)
                {
                    switch (cell.Id)
                    {
                        case CellType.None:
                            break;
                        case CellType.Green:
                            Gizmos.color = Color.green;
                            break;
                        case CellType.Red:
                            Gizmos.color = Color.red;
                            break;
                        case CellType.Purple:
                            Gizmos.color = Color.magenta;
                            break;
                        case CellType.Blue:
                            Gizmos.color = Color.blue;
                            break;
                        case CellType.Bomb:
                            Gizmos.color = Color.gray;
                            break;

                    }
                }
                else
                {
                    Gizmos.color = Color.black;
                }
                var position = new Vector3(posX, posY);
                Gizmos.DrawWireCube(position, levelData.CellSize/2);
                Handles.Label(position, cell?.name);
            }
        }

        private void OnDrawGizmos()
        {
            if (canDraft)
            {
                ShowGrid();
            }
        }
    }
}