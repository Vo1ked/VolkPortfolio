﻿using System;
using UnityEngine;
using VolkCore.Collections;

namespace VolkMatch3.Collections
{
    public class CellItemCollection : ItemsCollection<CellData> { }

    [Serializable]
    public struct CellData
    {
        [field:SerializeField] public CellType Id { get;private set; }
        [field:SerializeField] public Sprite Sprite { get;private set; }
        [field:SerializeField] public Vector2Int GridPosition { get;private set; }
        [field:SerializeField] public Vector2 Size { get;private set; }

        public CellData(CellType id, Sprite sprite, Vector2Int gridPosition, Vector2 size)
        {
            Id = id;
            Sprite = sprite;
            GridPosition = gridPosition;
            Size = size;
        }

        public void SetGridPosition(Vector2Int gridPosition)
        {
            GridPosition = gridPosition;
        }
    }

    public enum CellType
    {
        None = -1,
        Green = 0,
        Red = 1,
        Purple = 2,
        Blue = 3,
        Bomb =4,
    };
}