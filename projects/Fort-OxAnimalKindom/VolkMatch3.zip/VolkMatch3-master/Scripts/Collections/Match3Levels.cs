﻿using VolkCore.Save;

namespace VolkMatch3.Collections
{
    public class Match3Levels: AGameLevels<LevelData>
    {
        protected override string GameName => "Match3";
    }
}