﻿using System;
using UnityEngine;

namespace VolkMatch3.Collections
{
    [Serializable]
    public struct LevelData
    {
        public CollectRequest[] CollectRequests;
        public Vector2Int Size;
        public Vector2 CellSize;
    }

    [Serializable]
    public struct CollectRequest
    {
        public CellType Id;
        public int Count;
    }
}