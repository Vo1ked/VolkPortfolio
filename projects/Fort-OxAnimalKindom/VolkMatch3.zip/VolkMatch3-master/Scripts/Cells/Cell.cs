﻿using System;
using VolkCore.Collections;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using VolkMatch3.Collections;
using VolkMatch3.Signals;
using Zenject;

namespace VolkMatch3
{
    public class Cell : MonoBehaviour, IBeginDragHandler, IDragHandler, IEndDragHandler
    {
        
        public CellType Id=>_cellData.Id;
        public Vector2Int Direction { get; set; }

        public Vector2Int GridPosition
        {
            get=>_cellData.GridPosition;
            set=>_cellData.SetGridPosition(value);
        }

        [SerializeField] private CellData _cellData;
        [SerializeField] private Image _image;
        [Inject] private SignalBus _signalBus;
        
        private Vector2 _startDragPosition;

        protected virtual void Awake()
        {
            _image = GetComponentInChildren<Image>();
        }


        public void Initialize(CellData cellData)
        {
            _cellData = cellData;
            SetSprite(_cellData.Sprite);
            var rect = transform as RectTransform;
            rect.sizeDelta = _cellData.Size;
        }

        private void SetSprite(Sprite sprite)
        {
            _image.sprite = sprite;
        }

        public virtual void AfterMoveAction() { }

        public void OnBeginDrag(PointerEventData eventData)
        {
            _startDragPosition = eventData.position;
        }

        public void OnEndDrag(PointerEventData eventData)
        {
            Vector2 swipeDelta = (eventData.position - _startDragPosition).normalized;

            Direction = GetSwipeDirection(swipeDelta);

            _signalBus.Fire(new OnSwipeSignal(this));
        }

        private Vector2Int GetSwipeDirection(Vector2 swipeDelta)
        {
            if (Mathf.Abs(swipeDelta.x) > Mathf.Abs(swipeDelta.y))
            {
                return swipeDelta.x > 0 ? Vector2Int.right : Vector2Int.left;
            }

            return swipeDelta.y > 0 ? Vector2Int.down : Vector2Int.up;
        }

        public void OnDrag(PointerEventData eventData) { }
        
    }

}