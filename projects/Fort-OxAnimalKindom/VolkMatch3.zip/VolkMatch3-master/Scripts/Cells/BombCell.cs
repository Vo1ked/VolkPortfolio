﻿using System;
using VolkCore.Collections;
using VolkMatch3.Signals;
using Zenject;

namespace VolkMatch3
{
    public class BombCell : Cell, IBlowable
    {
        [Inject] private SignalBus _signalBus;
        public override void AfterMoveAction()
        {
            _signalBus.Fire(new OnBlowSignal(this));
        }

        public event Action<IBlowable> OnBlow;
        public int BlowRadius { get; } = 1;
    }
}