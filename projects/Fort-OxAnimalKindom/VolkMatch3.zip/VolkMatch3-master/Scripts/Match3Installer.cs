﻿using System;
using Save;
using UnityEngine;
using VolkCore.Collections;
using VolkCore.Game;
using VolkCore.Save;
using VolkCore.SceneManagement;
using VolkCore.Signals;
using VolkCore.UI;
using VolkMatch3.Collections;
using VolkMatch3.ItemPools;
using VolkMatch3.Signals;
using Zenject;

namespace VolkMatch3
{
    public class Match3Installer : ASceneInstaller
    {
        [SerializeField] private TopPanel _topPanel;
        [SerializeField] private ResultPopup _resultPopup;
        [SerializeField] private string _timerUiFormat = "TIME: {0}";
        [Space]
        [SerializeField] private Match3LevelsFactory _levelFactory;
        [SerializeField] private Cell _cellPrefab;
        [SerializeField] private BombCell _bombCellPrefab;
        [Space]
        [SerializeField] private Transform _gridContainer;
        [SerializeField] private ItemsCollection<CellData> _itemsCollection;
        [SerializeField] private int _roundTimeSeconds = 30;

        public override void InstallBindings()
        {
            if (!CheckAndLogDependencies())
                return;
            Container.Bind<TopPanel>().FromInstance(_topPanel).AsSingle();
            Container.Bind<ResultPopup>().FromInstance(_resultPopup);
            Container.Bind<PauseManager>().ToSelf().AsSingle();
            
            Container.BindInterfacesAndSelfTo<Timer>().FromNew().AsSingle();
            Container.Bind<string>().WithId("TimerStringFormat").FromInstance(_timerUiFormat).AsSingle();
            Container.Bind<TimeSpan>().FromInstance(new TimeSpan(0,0,_roundTimeSeconds)).AsCached();

            Container.Bind<ALevelFactory<LevelData>>().To<Match3LevelsFactory>().FromScriptableObject(_levelFactory).AsSingle();
            Container.Bind(typeof(AGameLevels<LevelData>),typeof(IInitializable)
                ,typeof(IDisposable),typeof(ILevelProgress)).To<Match3Levels>().AsSingle().NonLazy();
            
            Container.Bind<ItemsCollection<CellData>>().To<CellItemCollection>().FromScriptableObject(_itemsCollection).AsSingle();
            Container.Bind<CellsGrid>().ToSelf().FromNew().AsSingle().WithArguments(_gridContainer);
            Container.BindInterfacesAndSelfTo<CellFactory>().FromNew().AsSingle();

            Container.BindMemoryPool<Cell, CellPool<Cell>>()
                .WithInitialSize(100)
                .FromComponentInNewPrefab(_cellPrefab)
                .UnderTransform(_gridContainer.transform);
            
            Container.BindMemoryPool<BombCell, BombCellPool>()
                .WithInitialSize(20)
                .FromComponentInNewPrefab(_bombCellPrefab)
                .UnderTransform(_gridContainer.transform);
            
            Container.Bind(typeof(IInitializable),typeof(IDisposable)
                ,typeof(IPausable),typeof(IGameProgress)).To<Match3>().FromNew().AsSingle().NonLazy();

            Container.DeclareSignal<LevelSelectedSignal>();
            Container.DeclareSignal<OnSwipeSignal>();
            Container.DeclareSignal<OnBlowSignal>();
        }
    }
}