
namespace VolkMatch3.Signals
{
    public struct OnSwipeSignal
    {
        public Cell Cell;

        public OnSwipeSignal(Cell cell)
        {
            Cell = cell;
        }
    }

    public struct OnBlowSignal
    {
        public BombCell BombCell;

        public OnBlowSignal(BombCell bombCell)
        {
            BombCell = bombCell;
        }
    }
}