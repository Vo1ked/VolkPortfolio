﻿using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using VolkMatch3.Collections;

namespace VolkMatch3
{
    public class CheckAvailableMoves
    {
        public CheckAvailableMoves(int rowSize = 3)
        {
            _rowSize = rowSize;
        }
        
        private readonly int _rowSize;
        
        public bool HasMoves(Cell[,] grid)
        {
            int rows = grid.GetLength(0);
            int columns = grid.GetLength(1);

            for (int x = 0; x < rows; x++)
            {
                for (int y = 0; y < columns; y++)
                {
                    if (y + 1 < columns && TrySwapAndCheck(grid, x, y, x, y + 1))
                    {
                        return true;
                    }

                    if (x + 1 < rows && TrySwapAndCheck(grid, x, y, x + 1, y))
                    {
                        return true;
                    }
                }
            }

            return false;
        }

        private bool TrySwapAndCheck(Cell[,] grid, int x1, int y1, int x2, int y2)
        {
            var temp = grid[x1, y1];
            grid[x1, y1] = grid[x2, y2];
            grid[x2, y2] = temp;

            bool hasCombo = HasComboForCell(grid, grid[x1, y1], out _) || HasComboForCell(grid, grid[x2, y2], out _);

            temp = grid[x1, y1];
            grid[x1, y1] = grid[x2, y2];
            grid[x2, y2] = temp;

            return hasCombo;
        }

        public bool HasAnyCombo(Cell[,] grid, out List<Cell> combination)
        {
            int rows = grid.GetLength(0);
            int columns = grid.GetLength(1);
            combination = new List<Cell>();

            for (int x = 0; x < rows; x++)
            {
                for (int y = 0; y < columns; y++)
                {
                    if (HasComboForCell(grid, grid[x, y], out var combo))
                    {
                        combination.AddRange(combo);
                    }
                }
            }
            RemoveDuplicates(ref combination);

            return combination.Count > 0;
        }

        public void RemoveDuplicates(ref List<Cell> combination)
        {
            if (combination.Count < 1)
                return;
                
            var cells = combination
                .GroupBy(cell => cell.GridPosition)
                .Select(group => group.First())
                .ToList();

            combination = cells;
        }

        public bool HasComboForCell(Cell[,] grid, Cell cell, out List<Cell> combination)
        {
            combination = new List<Cell>();
            int x = cell.GridPosition.x;
            int y = cell.GridPosition.y;
            var id = cell.Id;

            bool hasHorizontalCombo = CheckHorizontalCombo(grid, x, y, id, out var horizontalCombo);
            bool hasVerticalCombo = CheckVerticalCombo(grid, x, y, id, out var verticalCombo);

            if (hasHorizontalCombo)
            {
                combination.AddRange(horizontalCombo);
            }

            if (hasVerticalCombo)
            {
                combination.AddRange(verticalCombo);
            }
            
            RemoveDuplicates(ref combination);

            return combination.Count >= _rowSize;
        }

        private bool CheckHorizontalCombo(Cell[,] grid, int x, int y, CellType id, out List<Cell> combination)
        {
            combination = new List<Cell> { grid[x, y] };

            int left = y - 1;
            while (left >= 0 && grid[x, left].Id == id)
            {
                combination.Add(grid[x, left]);
                left--;
            }

            int right = y + 1;
            while (right < grid.GetLength(1) && grid[x, right].Id == id)
            {
                combination.Add(grid[x, right]);
                right++;
            }

            return combination.Count >= _rowSize;
        }

        private bool CheckVerticalCombo(Cell[,] grid, int x, int y, CellType id, out List<Cell> combination)
        {
            combination = new List<Cell> { grid[x, y] };

            int up = x - 1;
            while (up >= 0 && grid[up, y].Id == id)
            {
                combination.Add(grid[up, y]);
                up--;
            }

            int down = x + 1;
            while (down < grid.GetLength(0) && grid[down, y].Id == id)
            {
                combination.Add(grid[down, y]);
                down++;
            }

            return combination.Count >= _rowSize;
        }
    }
}