﻿using UnityEngine;
using System.Collections.Generic;
using VolkCore.Game;
using VolkMatch3.Collections;

namespace VolkMatch3
{
    [CreateAssetMenu(fileName = "Match3LevelFactory", menuName = "Inventory/Match3 Level Factory", order = 0)]
    public class Match3LevelsFactory : ALevelFactory<LevelData>
    {
        [SerializeField] private LevelsAsset[] _levelsAssets = 
        {
            new LevelsAsset(new Vector2(88, 88),new Vector2Int(4, 6),new Vector2Int(0, 9),
                new []{CellType.Green, CellType.Blue, CellType.Red, CellType.Purple},new Vector2Int(3,5)),
            new LevelsAsset(new Vector2(65, 65),new Vector2Int(5, 6),new Vector2Int(10, 19),
                new []{CellType.Green, CellType.Blue, CellType.Red, CellType.Purple},new Vector2Int(6,10)),
            new LevelsAsset(new Vector2(50, 50),new Vector2Int(6, 8),new Vector2Int(20, 27),
                new []{CellType.Green, CellType.Blue, CellType.Red, CellType.Purple},new Vector2Int(11,15)),
        };
        
        public override LevelData[] GenerateLevels()
        {
            List<LevelData> levels = new List<LevelData>();
            int expectedIndex = 0;

            foreach (var asset in _levelsAssets)
            {
                Vector2 cellSize = asset.CellSize;
                Vector2Int mapSize = asset.MapSize;
                CellType[] cellIds = asset.CellIds;
                Vector2Int collectRange = asset.CollectRequests;
                Vector2Int levelRange = asset.LevelsRange;

                // Перевірка на пропущені рівні
                if (levelRange.x != expectedIndex)
                {
                    Debug.LogError($"Пропущені рівні: очікувався рівень з індексом {expectedIndex}, але наступний починається з {levelRange.x}");
                }

                for (int i = levelRange.x; i <= levelRange.y; i++)
                {
                    LevelData level = new LevelData
                    {
                        Size = mapSize,
                        CellSize = cellSize,
                        CollectRequests = GenerateCollectRequests(cellIds, collectRange)
                    };

                    levels.Add(level);
                    expectedIndex++;
                }
            }

            return levels.ToArray();
        }

        private CollectRequest[] GenerateCollectRequests(CellType[] cellIds, Vector2Int countRange)
        {
            List<CollectRequest> requests = new List<CollectRequest>();
            var availableColors = new List<CellType>(cellIds);

            for (int i = 0; i < 3 && availableColors.Count > 0; i++)
            {
                int index = Random.Range(0, availableColors.Count);
                CellType color = availableColors[index];
                availableColors.RemoveAt(index);

                requests.Add(new CollectRequest
                {
                    Id = color,
                    Count = Random.Range(countRange.x, countRange.y + 1)
                });
            }

            return requests.ToArray();
        }

        [System.Serializable]
        private struct LevelsAsset
        {
            [field: SerializeField] public Vector2 CellSize { get; private set; }
            [field: SerializeField] public Vector2Int MapSize { get; private set; }
            [field: SerializeField] public Vector2Int LevelsRange { get; private set; }
            [field: SerializeField] public CellType[] CellIds { get; private set; }
            [field: SerializeField] public Vector2Int CollectRequests { get; private set; }

            public LevelsAsset(Vector2 cellSize, Vector2Int mapSize, Vector2Int levelsRange
                , CellType[] cellIds, Vector2Int collectRequests)
            {
                CellSize = cellSize;
                MapSize = mapSize;
                LevelsRange = levelsRange;
                CellIds = cellIds;
                CollectRequests = collectRequests;
            }
        }
    }
    
}