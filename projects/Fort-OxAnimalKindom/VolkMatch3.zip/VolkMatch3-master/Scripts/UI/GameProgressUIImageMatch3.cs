﻿using System;
using System.Collections.Generic;
using VolkCore.Collections;
using UnityEngine;
using UnityEngine.UI;
using VolkCore.Game;
using VolkMatch3.Collections;
using Zenject;

namespace VolkMatch3.UI
{
    public class GameProgressUIImageMatch3 : MonoBehaviour
    {
        [Inject] private IGameProgress _gameProgress;
        [Inject] private ItemsCollection<CellData> _cells;
        [SerializeField] private Image _image;
        [SerializeField] private int _imageId;

        public async void Awake()
        {
            await _gameProgress;
            Changed(_gameProgress.GameProgress);
            _gameProgress.OnChanged += Changed;
        }

        private void OnDestroy()
        {
            _gameProgress.OnChanged -= Changed;
        }

        private void Changed(IReadOnlyDictionary<int, IGoalProgress> gameProgresses)
        {
            var cell = _cells.Items
                .Find(item=>item.Data.Id == Enum.Parse<CellType>(gameProgresses[_imageId].ItemId.Value.ToString()));
            _image.sprite = cell.Data.Sprite;
        }
    }
}