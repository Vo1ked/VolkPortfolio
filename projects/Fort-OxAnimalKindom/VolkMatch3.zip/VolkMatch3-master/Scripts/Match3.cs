﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using PrimeTween;
using UnityEngine;
using Zenject;
using VolkCore.Collections;
using VolkCore.Game;
using VolkCore.Save;
using VolkCore.SceneManagement.UI;
using VolkCore.Signals;
using VolkCore.Tools;
using VolkCore.UI;
using VolkMatch3.Collections;
using VolkMatch3.ItemPools;
using VolkMatch3.Signals;
using Timer = VolkCore.Game.Timer;

namespace VolkMatch3
{
    public class Match3 : IInitializable, IDisposable, IPausable, IGameProgress
    {
        public Action OnInited { get; set; }
        public bool Inited { get; private set; }
        public IReadOnlyDictionary<int, IGoalProgress> GameProgress=>_gameProgress.ToDictionary(
            keyValuePair=>keyValuePair.Key,
            keyValuePair=>(IGoalProgress)keyValuePair.Value);
        public event Action<IReadOnlyDictionary<int, IGoalProgress>> OnChanged;

        [Inject] private AGameLevels<LevelData> _levels;
        [Inject] private Timer _timer;
        [Inject] private ILoadingScreen _loadingScreen;
        [Inject] private IBalance _balance;
        [Inject] private ResultPopup _resultPopup;
        [Inject] private CellFactory _cellFactory;
        [Inject] private ItemsCollection<CellData> _cellItems;
        [Inject] private CellsGrid _grid;
        [Inject] private SignalBus _signalBus;
        [Inject] private TimeSpan _roundTime;

        private readonly List<Cell> _cellsToRemove = new List<Cell>();
        private readonly CheckAvailableMoves _availableMoves = new CheckAvailableMoves();

        private Dictionary<int, GoalProgress> _gameProgress;
        private CancellationTokenSource _cts;
        private bool _swipeInProgress;
        private bool _customActionInProgress;
        
        public void Initialize()
        {
            PrimeTweenConfig.warnEndValueEqualsCurrent = false;
            _cts = new CancellationTokenSource();

            _timer.TimerEnd += ShowLosePopup;
            _signalBus.Subscribe<OnSwipeSignal>(OnSwipe);
            _signalBus.Subscribe<OnBlowSignal>(OnBlow);
            _signalBus.Subscribe<LevelSelectedSignal>(StartGame);
            _ = InitAsync();
        }
        
        public InitAwaiter GetAwaiter() => new InitAwaiter(this);

        private async Awaitable InitAsync()
        {
            await _levels;
            _gameProgress = new Dictionary<int, GoalProgress>
            {
                {
                    0, new GoalProgress(new ReactiveVariable<int>((int)_levels.CurrentLevel.CollectRequests[0].Id),
                        new ReactiveVariable<float>(0),
                        new ReactiveVariable<float>(_levels.CurrentLevel.CollectRequests[0].Count))
                },
                {
                    1, new GoalProgress(new ReactiveVariable<int>((int)_levels.CurrentLevel.CollectRequests[1].Id),
                        new ReactiveVariable<float>(0),
                        new ReactiveVariable<float>(_levels.CurrentLevel.CollectRequests[1].Count))
                },
                {
                    2, new GoalProgress(new ReactiveVariable<int>((int)_levels.CurrentLevel.CollectRequests[2].Id),
                        new ReactiveVariable<float>(0),
                        new ReactiveVariable<float>(_levels.CurrentLevel.CollectRequests[2].Count))
                }
            };
            _loadingScreen.TryHide();
            Inited = true;
            OnInited?.Invoke();
        }

        private async void OnBlow(OnBlowSignal onBlowSignal)
        {
            _customActionInProgress = true;
            _cellsToRemove.Clear();
            var blowRadius = onBlowSignal.BombCell.BlowRadius;
            Cell cell = onBlowSignal.BombCell;

            var blowsCells = GetCellsInRadius(cell.GridPosition, blowRadius);
            blowsCells.Add(cell);
            var cellsToBlow = new HashSet<Cell>(blowsCells);
    
            await ProcessExplosions(cellsToBlow);

            _customActionInProgress = false;
        }

        private async Task ProcessExplosions(IEnumerable<Cell> startCells)
        {
            var queue = new Queue<Cell>(startCells);
            var allBlown = new HashSet<Cell>(startCells);

            while (queue.Count > 0)
            {
                var cell = queue.Dequeue();

                if (cell is IBlowable blowable)
                {
                    var neighbors = GetCellsInRadius(cell.GridPosition, blowable.BlowRadius);
                    foreach (var n in neighbors)
                    {
                        if (allBlown.Add(n))
                            queue.Enqueue(n);
                    }
                }
            }
            var allCels = new List<Cell>(allBlown);
            _availableMoves.RemoveDuplicates(ref allCels);
            _cellsToRemove.AddRange(allCels);
            await AnimateWinLines(_cellsToRemove);

            await AddNewCells();
            _customActionInProgress = false;
        }

        
        private List<Cell> GetCellsInRadius(Vector2Int center, int radius)
        {
            var result = new List<Cell>();
    
            for (int x = center.x - radius; x <= center.x + radius; x++)
            {
                for (int y = center.y - radius; y <= center.y + radius; y++)
                {
                    if (x < 0 || x >= _grid.Grid.GetLength(0) || y < 0 || y >= _grid.Grid.GetLength(1))
                        continue;
                    var cell = _grid.Grid[x, y];
                    if (cell != null)
                    {
                        result.Add(cell);
                    }
                }
            }
    
            return result;
        }

        private async void OnSwipe(OnSwipeSignal onSwipeSignal)
        {
            if (_swipeInProgress || _cts.IsCancellationRequested || _customActionInProgress)
            {
                return;
            }
            _swipeInProgress = true;
            var cell = onSwipeSignal.Cell;
            if (!CanMove(cell))
            {
                _swipeInProgress = false;
                return;
            }
            await MoveCells(cell);
            await Awaitable.NextFrameAsync();
            _availableMoves.HasComboForCell(_grid.Grid, cell, out var result);
            var cell2 = _grid.Grid[cell.GridPosition.x + cell.Direction.x * -1, cell.GridPosition.y + cell.Direction.y * -1];
            _availableMoves.HasComboForCell(_grid.Grid, cell2, out var result2);
            cell.AfterMoveAction();
            cell2.AfterMoveAction();
            _cellsToRemove.AddRange(result);
            _cellsToRemove.AddRange(result2);
            while (_customActionInProgress)
            {
                await Awaitable.NextFrameAsync();
            }
            if (_cts.IsCancellationRequested)
            {
                return;
            }
            if (_cellsToRemove.Count > 0)
            {
                await AnimateWinLines(_cellsToRemove);
            }
            else
            {
                cell.Direction = new Vector2Int(cell.Direction.x * -1, cell.Direction.y * -1);
                await MoveCells(cell);
            }

            if (CheckWin())
            {
                ShowWinPopup();
                return;
            }

            if (!_availableMoves.HasMoves(_grid.Grid))
            {
                _cellFactory.GenerateGrid(_levels.CurrentLevel);
            }
            _cellsToRemove.Clear();
            _swipeInProgress = false;
        }

        private bool CanMove(Cell cell)
        {
            return cell.GridPosition.x + cell.Direction.x >= 0 &&
                   cell.GridPosition.x + cell.Direction.x < _grid.Grid.GetLength(0)
                   || cell.GridPosition.y + cell.Direction.y >= 0 &&
                   cell.GridPosition.y + cell.Direction.y < _grid.Grid.GetLength(1);
        }

        private async Task MoveCells(Cell cell)
        {
            var gridPosition = new Vector2Int(cell.GridPosition.x + cell.Direction.x, cell.GridPosition.y + cell.Direction.y);
            
            if (gridPosition.x < 0 || gridPosition.x >= _grid.Grid.GetLength(0) ||
                gridPosition.y < 0 || gridPosition.y >= _grid.Grid.GetLength(1))
            {
                return;
            }
            
            var targetCell = _grid.Grid[gridPosition.x, gridPosition.y];
            Vector3 center = (cell.transform.position + targetCell.transform.position) * 0.5f;
            await Sequence.Create(1)
                .Group(Tween.Position(cell.transform, center, 0.25f, Ease.InOutQuad))
                .Group(Tween.Position(targetCell.transform, center, 0.25f, Ease.InOutQuad))
                .Chain(Tween.Position(cell.transform, targetCell.transform.position, 0.25f, Ease.InOutQuad))
                .Group(Tween.Position(targetCell.transform, cell.transform.position, 0.25f, Ease.InOutQuad));
            
            (cell.GridPosition, targetCell.GridPosition) = (targetCell.GridPosition, cell.GridPosition);
            _grid.Grid[cell.GridPosition.x, cell.GridPosition.y] = cell;
            _grid.Grid[targetCell.GridPosition.x, targetCell.GridPosition.y] = targetCell;
        }

        private async Task AnimateWinLines(List<Cell> cells)
        {
            var toRemove = new List<Cell>(cells);
            cells.Clear();
            var sequence = Sequence.Create();
            toRemove.ForEach(cell=>sequence.Group(Tween.Scale(cell.transform, Vector3.zero, 0.5f)));
            
            await sequence;
            
            await RemoveWinLines(toRemove);
            await AddNewCells();
            await MoveCellsDown();
            await Awaitable.WaitForSecondsAsync(0.3f);

            if (_cts.IsCancellationRequested)
            {
                return;
            }
            if (_availableMoves.HasAnyCombo(_grid.Grid,out var combination))
            {
                await AnimateWinLines(combination);
            }
        }

        private async Task RemoveWinLines(List<Cell> cells)
        {
            bool invalid = false;
            int width  = _grid.Grid.GetLength(0);
            int height = _grid.Grid.GetLength(1);
            var toRemove = new List<Cell>();

            foreach (var cell in cells)
            {
                if (cell == null
                    || cell.GridPosition.x < 0 || cell.GridPosition.x >= width
                    || cell.GridPosition.y < 0 || cell.GridPosition.y >= height)
                {
                    invalid = true;
                    break;
                }
                toRemove.Add(cell);
            }

            if (invalid)
            {
                Debug.LogWarning("RemoveWinLines: received invalid data → recreating grid");
                RecreateGrid();
                return;
            }

            // 2) Основна логіка (без змін)
            _availableMoves.RemoveDuplicates(ref toRemove);
            foreach (var cell in toRemove)
            {
                foreach (var kv in _gameProgress)
                {
                    if (kv.Value.ItemId.Value == (int)cell.Id)
                        kv.Value.CurrentValue.Value++;
                }

                _grid.Grid[cell.GridPosition.x, cell.GridPosition.y] = null;
                _cellFactory.Despawn(cell);
            }

            OnChanged?.Invoke(GameProgress);
            await Awaitable.NextFrameAsync();
        }

        private void RecreateGrid()
        {
            _cellFactory.GenerateGrid(_levels.CurrentLevel);
            _swipeInProgress = false;
            _customActionInProgress = false;
        }


        private void MoveCellDown(Cell cell)
        {
            var posY = cell.GridPosition.y + 1;
            
            if (posY >= _grid.Grid.GetLength(1))
                return;
            
            if (_grid.Grid[cell.GridPosition.x, posY] == null)
            {
                _grid.Grid[cell.GridPosition.x, posY - 1] = null;
                _grid.Grid[cell.GridPosition.x, posY] = cell;
                _grid.Grid[cell.GridPosition.x, posY].GridPosition = new Vector2Int(cell.GridPosition.x, posY);
            }
            else
            {
                return;
            }
            
            MoveCellDown(cell);
        }

        private Cell FindCell(int x, int y)
        {
            var posY = y - 1;
            if (posY < 0)
             return null;
            
            var result = _grid.Grid[x, posY];

            if (result == null)
                return FindCell(x, posY);
            return result;
        }

        private async Task AddNewCells()
        {
            for (int x = 0; x < _grid.Grid.GetLength(0); x++)
            {
                var lowwestEmptyCell = 0;
                for (int y = _grid.Grid.GetLength(1); y >= 0; y--)
                {
                    var cell = FindCell(x, y);
                    if (cell == null)
                        continue;
                    MoveCellDown(cell);
                }
                while (_grid.Grid[x,lowwestEmptyCell] == null)
                {
                    lowwestEmptyCell++;
                    if (lowwestEmptyCell >= _grid.Grid.GetLength(1))
                    {
                        break;
                    }
                }
                

                var spawnPointUpderGrid = -1;
                for (int y = lowwestEmptyCell -1 ; y >= 0 ; y--)
                {
                    var newItem = _cellFactory.SpawnRandomCell(x,spawnPointUpderGrid,_levels.CurrentLevel);
                    _grid.Grid[x,y] = newItem;
                    newItem.GridPosition = new Vector2Int(x,y);
                    spawnPointUpderGrid--;
                }
            }
            await Awaitable.NextFrameAsync();
        }

        private async Task MoveCellsDown()
        {
            var levelData = _levels.CurrentLevel; 
            var sequence = Sequence.Create();
            
            for (int x = 0; x < _grid.Grid.GetLength(0); x++)
                for (int y = 0; y < _grid.Grid.GetLength(1); y++)
                {
                    float offsetX = -levelData.Size.x * levelData.CellSize.x / 2 + levelData.CellSize.x / 2;
                    float offsetY = levelData.Size.y * levelData.CellSize.y / 2 - levelData.CellSize.y / 2;
                    float posX = x * levelData.CellSize.x + offsetX;
                    float posY = -y * levelData.CellSize.y + offsetY;
                    Vector3 targetPosition = new Vector3(posX, posY);
                    sequence.Group(Tween.LocalPosition(_grid.Grid[x, y].transform, targetPosition, 0.5f, Ease.InOutQuad));
                }
            
            await sequence;
            
            if (_cts.IsCancellationRequested)
            {
                return;
            }
            await Awaitable.NextFrameAsync();
        }

        public void Dispose()
        {
            _cts.Cancel();
            _cts.Dispose();
            _signalBus.Unsubscribe<LevelSelectedSignal>(StartGame);
            _signalBus.Unsubscribe<OnBlowSignal>(OnBlow);
            _signalBus.Unsubscribe<OnSwipeSignal>(OnSwipe);
            PrimeTweenConfig.warnEndValueEqualsCurrent = true;
        }

        private bool CheckWin()
        {
            foreach (var progress in GameProgress.Values)
            {
                Debug.Log($"CheckWin For {Enum.Parse(typeof(CellType), progress.ItemId.Value.ToString())}:  {progress.Current.Value} / {progress.Max.Value}");
            }

            return GameProgress.Values.All(p => (int)p.Current.Value >= (int)p.Max.Value);
        }
        
        private void ShowWinPopup()
        {
            OnGameEnd();
            _levels.IncrementLevel();
            _balance.Balance.Value += 200;
            _resultPopup.OnRetry += StartNextLevel; 
            _ = _resultPopup.SetWin(200, -1, _cts.Token);
        }

        private void OnGameEnd()
        {
            _timer.StopTimer();
            _cts.Cancel();
        }

        private  void ShowLosePopup()
        {
            _timer.StopTimer();
            OnGameEnd();
            _balance.Balance.Value -= 100;
            _resultPopup.OnRetry += RetryLevel; 
            _ = _resultPopup.SetLose(100,-1,_cts.Token);
        }
        private void StartNextLevel()
        {
            _resultPopup.OnRetry -= StartNextLevel; 
            _levels.SelectLevel(_levels.CurrentLevelId.Value + 1);
            StartGame();
        }

        private void RetryLevel()
        {
            _resultPopup.OnRetry -= RetryLevel;
            StartGame();
        }

        private void StartGame()
        {
            if (_levels.Levels == null)
            {
                Debug.LogError("Levels not initialized.");
                return;
            }

            _timer.Initialize(_roundTime);
            _cts = new CancellationTokenSource();
            _swipeInProgress = false;
            _customActionInProgress = false;
            _cellsToRemove.Clear();
            _cellFactory.GenerateGrid(_levels.CurrentLevel);
            
            for (int i = 0; i < _levels.CurrentLevel.CollectRequests.Length; i++)
            {
                _gameProgress[i].ItemIdValue.Value = (int)_levels.CurrentLevel.CollectRequests[i].Id;
                _gameProgress[i].CurrentValue.Value = 0;
                _gameProgress[i].MaxValue.Value = _levels.CurrentLevel.CollectRequests[i].Count;
            }
            
            OnChanged?.Invoke(GameProgress);
            _timer.StartTimer();
        }


        public void OnPause()
        {
            foreach (var cell in _grid.Grid)
            {
                Tween.SetPausedAll(true, cell.transform);
            }
        }

        public void OnResume()
        {
            foreach (var cell in _grid.Grid)
            {
                Tween.SetPausedAll(false, cell.transform);
            }
        }
    }
}