﻿namespace VolkMatch3.ItemPools
{
    public class BombCellPool : CellPool<BombCell> { }
}