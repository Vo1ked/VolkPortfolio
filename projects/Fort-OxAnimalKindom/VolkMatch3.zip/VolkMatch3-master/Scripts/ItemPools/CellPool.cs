﻿using UnityEngine;
using VolkCore.Game;
using VolkMatch3.Collections;
using Zenject;

namespace VolkMatch3.ItemPools
{
    public class CellPool<TItem> : MonoMemoryPool<CellData,PrefabData,TItem > where TItem : Cell
    {
        protected override void OnCreated(TItem item)
        {
            item.gameObject.SetActive(false);
        }
        
        protected override void OnSpawned(TItem item)
        {
            item.gameObject.SetActive(true);
        }

        protected override void OnDespawned(TItem item)
        {
            item.gameObject.SetActive(false);
            item.GridPosition = new Vector2Int(-100, -100);
        }

        protected override void Reinitialize(CellData p1, PrefabData parent, TItem item)
        {
            item.Initialize(p1);
            
            item.transform.localPosition = parent.Position;
            item.transform.localRotation = parent.Rotation;
            item.transform.localScale = Vector3.one;
            item.gameObject.name = $"{typeof(TItem).Name}({item.Id})[{item.GridPosition.x},{item.GridPosition.y}]";

            if (parent.Parent != null)
            {
                item.transform.SetParent(parent.Parent);
            }
        }
    }
}