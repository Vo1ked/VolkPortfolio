﻿using UnityEngine;

namespace VolkMatch3
{
    public class CellsGrid
    {
        public Cell[,] Grid;
        public readonly Transform Container;

        public CellsGrid(Transform container)
        {
            Container = container;
        }
    }
}