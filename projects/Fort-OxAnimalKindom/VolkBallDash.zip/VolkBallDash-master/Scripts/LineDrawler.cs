﻿using System.Collections.Generic;
using UnityEngine;
using VolkBallDash.ItemPools;
using VolkBallDash.Signal;
using VolkCore.Game;
using VolkInput;
using Zenject;

namespace VolkBallDash
{
    public class LineReader : MonoBehaviour
    {
        public bool IsDrawing = false;

        [Inject] private LineRendererPool _lineRendererPool;
        [Inject] private IVolkInput _volkInput;
        [Inject] private SignalBus _signalBus;

        private List<Vector3> _linePositions = new List<Vector3>();
        private List<Start> _startPoints; 
        private LineRenderer _lineRenderer;
        private int _startId = -1;
        private bool _startedFromPosition = false;

        private void Awake()
        {
            _lineRenderer = _lineRendererPool.Spawn(new PrefabData(Vector3.zero, Quaternion.identity,transform));
            _volkInput.OnPressStart += StartDrawing;
            _volkInput.OnPressContinue += AddPoint;
            _volkInput.OnPressEnd += StopDrawing;
        }

        private void OnDestroy()
        {
            _volkInput.OnPressStart -= StartDrawing;
            _volkInput.OnPressContinue -= AddPoint;
            _volkInput.OnPressEnd -= StopDrawing;
        }


        public void SetStartPoints(List<Start> startPoints)
        {
            _startPoints = startPoints;
        }

        private void StartDrawing(Vector2 startPosition)
        {
            if (!IsDrawing)
                return;

            _startedFromPosition = false;
            foreach (var point in _startPoints)
            {
                if (IsTouchWithinCollider(startPosition, point.Collider))
                {
                    _startedFromPosition = true;
                    _startId = point.Ball.Id;
                    break;
                }
            }

            if (!_startedFromPosition)
                return;
            

            _lineRenderer.positionCount = 0;
            _linePositions.Clear();
            AddPoint(startPosition);
        }


        private bool IsTouchWithinCollider(Vector2 touchPosition, Collider2D collider)
        {
            Vector3 worldPosition = Camera.main.ScreenToWorldPoint
                (new Vector3(touchPosition.x, touchPosition.y, 0));
            var result = collider.OverlapPoint(worldPosition);
            return result;
        }

        private void AddPoint(Vector2 touchPosition)
        {
            if (!IsDrawing || !_startedFromPosition)
                return;
            
            Vector3 worldPosition = Camera.main.ScreenToWorldPoint
                (new Vector3(touchPosition.x, touchPosition.y, Camera.main.nearClipPlane));

            if (_linePositions.Count == 0 || Vector3.Distance(worldPosition, _linePositions[^1]) > 0.1f)
            {
                _linePositions.Add(worldPosition);
                _lineRenderer.positionCount = _linePositions.Count;
                _lineRenderer.SetPosition(_lineRenderer.positionCount - 1, worldPosition);
            }
        }

        private void StopDrawing(Vector2 endPosition)
        {
            if (!IsDrawing || !_startedFromPosition)
                return;
            IsDrawing = false;
            _signalBus.Fire(new OnLineDrawnSignal(_linePositions.ToArray(),_startId));
        }

        public void ClearLine()
        {
            _lineRendererPool.Despawn(_lineRenderer);
            _lineRenderer = _lineRendererPool.Spawn(new PrefabData(Vector3.zero, Quaternion.identity,transform));
        }
    }
}
