﻿using System.Collections.Generic;
using UnityEngine;
using VolkBallDash.ItemPools;
using VolkCore.Game;
using Zenject;

namespace VolkBallDash
{
    public class BallDashLevelBuilder : MonoBehaviour
    {
        [SerializeField] Vector2 _offset;
        [Inject] private StartPool _startPool;
        [Inject] private FinishPool _finishPool;
        [Inject] private CoinPool _coinPool;
        [Inject] private WallPool _wallPool;
        
        [Inject] private List<Start> _starts;
        [Inject] private List<Finish> _finishes;
        [Inject] private List<Coin> _coins;
        [Inject] private List<Wall> _walls;

        public void GenerateLevel(LevelData levelData)
        {
            ClearLevel();

            for (var i = 0; i < levelData.StartPositions.Length; i++)
            {
                var position = levelData.StartPositions[i];
                var start = _startPool.Spawn(new PrefabData(position + _offset, Quaternion.identity, transform));
                start.Ball.SetColor(i);
                _starts.Add(start);
            }

            for (var i = 0; i < levelData.FinishPositions.Length; i++)
            {
                var position = levelData.FinishPositions[i];
                var finish = _finishPool.Spawn(new PrefabData(position + _offset, Quaternion.identity, transform));
                finish.SetColor(i);
                _finishes.Add(finish);
            }

            foreach (var position in levelData.CoinPositions)
            {
                var coin = _coinPool.Spawn(new PrefabData(position + _offset, Quaternion.identity, transform));
                _coins.Add(coin);
            }

            foreach (var position in levelData.WallPositions)
            {
                var wall = _wallPool.Spawn(new PrefabData(position + _offset, Quaternion.identity, transform));
                _walls.Add(wall);
            }
        }

        public List<Start> GetStarts()
        {
            return _starts;
        }
        
        public List<Finish> GetFinishes()
        {
            return _finishes;
        }

        public void ReturnCoin(ICollecteble coin)
        {
            _coins.Remove((Coin)coin);
            _coinPool.Despawn((Coin)coin);
        }

        private void ClearLevel()
        {
            foreach (var start in _starts)
            {
                _startPool.Despawn(start);
            }
            _starts.Clear();

            foreach (var finish in _finishes)
            {
                _finishPool.Despawn(finish);
            }
            _finishes.Clear();

            foreach (var coin in _coins)
            {
                _coinPool.Despawn(coin);
            }
            _coins.Clear();

            foreach (var wall in _walls)
            {
                _wallPool.Despawn(wall);
            }
            _walls.Clear();
        }
    }
}
