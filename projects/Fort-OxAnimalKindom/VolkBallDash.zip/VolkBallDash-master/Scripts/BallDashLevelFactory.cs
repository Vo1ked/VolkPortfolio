﻿using UnityEngine;
using VolkCore.Game;

namespace VolkBallDash
{
    [CreateAssetMenu(fileName = "BallDashLevelFactory", menuName = "Inventory/Ball Dash Level Factory", order = 0)]
    public class BallDashLevelFactory : ALevelFactory<LevelData>
    {
        [SerializeField] private LevelData[] ballDashLevelsData;
        public LevelData[] BallDashLevelsData => ballDashLevelsData;

        public override LevelData[] GenerateLevels()
        {
            return ballDashLevelsData;
        }

        public void SetLevelsData(LevelData[] newLevels)
        {
            ballDashLevelsData = newLevels;
        }
    }
}