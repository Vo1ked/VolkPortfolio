﻿using UnityEngine;
using VolkCore.Game;

namespace VolkBallDash.ItemPools
{
    public class LineRendererPool : BaseMonoPool<LineRenderer>
    {
        protected override void OnDespawned(LineRenderer item)
        {
            base.OnDespawned(item);
            item.positionCount = 0;
        }
    }
}