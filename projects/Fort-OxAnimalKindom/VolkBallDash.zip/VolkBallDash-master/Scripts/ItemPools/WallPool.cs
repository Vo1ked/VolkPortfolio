﻿using VolkCore.Game;

namespace VolkBallDash.ItemPools
{
    public class WallPool : BaseMonoPool<Wall> { }
}