using VolkCore.Game;

namespace VolkBallDash.ItemPools
{
    public class FinishPool : BaseMonoPool<Finish>{}
}