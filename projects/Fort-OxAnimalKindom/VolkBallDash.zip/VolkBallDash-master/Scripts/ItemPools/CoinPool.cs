﻿using VolkCore.Game;

namespace VolkBallDash.ItemPools
{
    public class CoinPool : BaseMonoPool<Coin> { }
}