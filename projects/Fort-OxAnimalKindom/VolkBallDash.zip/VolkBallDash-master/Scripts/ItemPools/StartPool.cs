﻿using UnityEngine;
using VolkCore.Game;

namespace VolkBallDash.ItemPools
{
    public class StartPool : BaseMonoPool<Start>
    {
        protected override void OnDespawned(Start item)
        {
            base.OnDespawned(item);
            item.Ball.transform.localPosition = Vector3.zero;
        }
    }
}