using UnityEngine;

namespace VolkBallDash.Signal
{
    public struct CollectedSignals
    {
        public ICollecteble Collecteble { get; }

        public CollectedSignals(ICollecteble collecteble)
        {
            Collecteble = collecteble;
        }
    }

    public struct OnDamageSignal
    {
        public IDamageDealer DamageDealer { get; }

        public OnDamageSignal(IDamageDealer damageDealer)
        {
            DamageDealer = damageDealer;
        }
    }

    public struct OnLineDrawnSignal
    {
        public Vector3[] LinePoints { get; }
        public int BallId { get; }

        public OnLineDrawnSignal(Vector3[] linePoints, int ballId)
        {
            LinePoints = linePoints;
            BallId = ballId;
        }

    }
}