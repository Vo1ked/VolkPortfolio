﻿using UnityEngine;
using UnityEditor;
using VolkBallDash.Tools;

namespace VolkBallDash.Editor
{
    [CustomEditor(typeof(BallDashLevelSaver))]
    public class BallDashLevelSaverEditor : UnityEditor.Editor
    {
        public override void OnInspectorGUI()
        {
            DrawDefaultInspector();

            BallDashLevelSaver levelSaver = (BallDashLevelSaver)target;

            if (GUILayout.Button("Save Levels"))
            {
                levelSaver.SaveLevel(); 
            }
            
            if (GUILayout.Button("Load Levels"))
            {
                levelSaver.LoadLevel();
            }
        }
    }
}
