﻿using UnityEngine;
using VolkBallDash.Signal;
using Zenject;

namespace VolkBallDash
{
    public class Coin : MonoBehaviour, ICollecteble
    {
        [Inject] private SignalBus _signalBus;

        private void OnTriggerEnter2D(Collider2D other) => _signalBus.Fire(new CollectedSignals(this));
    }
}