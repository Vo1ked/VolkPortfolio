﻿using UnityEngine;
using VolkBallDash.Signal;
using Zenject;

namespace VolkBallDash
{
    public class Wall : MonoBehaviour, IDamageDealer
    {
        [Inject] private SignalBus _signalBus;

        public void OnTriggerEnter2D(Collider2D other) => _signalBus.Fire(new OnDamageSignal(this));
    }
}