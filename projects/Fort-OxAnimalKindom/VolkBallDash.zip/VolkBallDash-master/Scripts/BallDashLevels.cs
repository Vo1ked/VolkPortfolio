﻿using UnityEngine;
using VolkCore.Save;

namespace VolkBallDash
{
    public class BallDashLevels : AGameLevels<LevelData>
    {
        protected override string GameName=>"BallDash";

        protected override async Awaitable LoadLevels()
        {
            Levels = LevelFactory.GenerateLevels();
        }

    }
}