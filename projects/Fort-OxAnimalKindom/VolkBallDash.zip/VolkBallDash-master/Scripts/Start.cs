﻿using UnityEngine;

namespace VolkBallDash
{
    public class Start : MonoBehaviour
    {
        [SerializeField] Ball _ball;
        public Ball Ball => _ball;
        
        public Collider2D Collider;

        public void Awake()
        {
            Collider = GetComponent<Collider2D>();
        }
    }
}