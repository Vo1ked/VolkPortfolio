﻿using System;
using UnityEngine;

namespace VolkBallDash
{
    [Serializable]
    public struct LevelData
    {
        public int Level;
        public Vector2[] CoinPositions;
        public Vector2[] WallPositions;
        public Vector2[] StartPositions;
        public Vector2[] FinishPositions;
    }
}