﻿using UnityEngine;

namespace VolkBallDash
{
    public class Finish : MonoBehaviour
    {
        [SerializeField] private SpriteRenderer _spriteRenderer;
        [SerializeField] private Sprite[] _sprites;
        [SerializeField] private Collider2D _collider2D;
        public int Id;
        public Collider2D Collider2D => _collider2D;

        private void Awake()
        {
            if (_collider2D == null)
                _collider2D = GetComponent<Collider2D>();
        }

        public void SetColor(int id)
        {
            _spriteRenderer.sprite = _sprites[id];
            Id = id;
        }
    }
}