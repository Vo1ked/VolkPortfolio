﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using UnityEngine;
using VolkBallDash.Signal;
using VolkCore.Collections;
using VolkCore.Save;
using VolkCore.Signals;
using VolkCore.UI;
using Zenject;
using Timer = VolkCore.Game.Timer;

namespace VolkBallDash
{
    public class BallDash: IInitializable, IDisposable, IPausable
    {
        [Inject] private SignalBus _signalBus;
        [Inject] private ResultPopup _resultPopup;
        [Inject] private Timer _timer;
        [Inject] private TimeSpan _roundTime;
        [InjectOptional] private IBalance _balance;

        [Inject] private BallDashLevelBuilder _levelBuilder;
        [Inject] private AGameLevels<LevelData> _levels;
        [Inject] private LineReader _lineReader;

        private int _currentBallId = -1;
        private int _coinsCollected = 0;
        private CancellationTokenSource _cancellationTokenSource;
        private Vector3[] _lastPath;
        private List<bool> _wins = new List<bool>();
        private bool _isPaused;
        private bool _wallTouched;
        public void Initialize()
        {
            _signalBus.Subscribe<OnDamageSignal>(DamagerOnHit);
            _signalBus.Subscribe<CollectedSignals>(Collected);
            _signalBus.Subscribe<OnLineDrawnSignal>(MoveBall);
            _signalBus.Subscribe<LevelSelectedSignal>(StartGame);
            _timer.TimerEnd += ShowLosePopup;
            _cancellationTokenSource = new CancellationTokenSource();
        }
        public void Dispose()
        {
            _signalBus.Unsubscribe<OnDamageSignal>(DamagerOnHit);
            _signalBus.Unsubscribe<CollectedSignals>(Collected);
            _signalBus.Unsubscribe<OnLineDrawnSignal>(MoveBall);
            _signalBus.Unsubscribe<LevelSelectedSignal>(StartGame);

            _timer.TimerEnd -= ShowLosePopup;
        }
        private void Collected(CollectedSignals signal)
        {
            _levelBuilder.ReturnCoin(signal.Collecteble);
            _coinsCollected++;
        }

        private async void MoveBall(OnLineDrawnSignal onLineDrawn)
        {
            _currentBallId = onLineDrawn.BallId;
            _lastPath = onLineDrawn.LinePoints;
            var ball = _levelBuilder.GetStarts()[_currentBallId].Ball;
            _lineReader.IsDrawing = false;

            foreach (var point in _lastPath)
            {
                Vector3 startPosition = ball.transform.position;
                float timeElapsed = 0f;
                float moveDuration = 0.05f; 
                _timer.OnPause();
                while (timeElapsed < moveDuration)
                {
                    if (_cancellationTokenSource.IsCancellationRequested)
                    {
                        break;
                    }

                    if (_isPaused)
                    {
                        await Awaitable.NextFrameAsync();
                        continue;
                    }
                    
                    ball.transform.position = Vector3.Lerp(startPosition, point, timeElapsed / moveDuration);
                    timeElapsed += Time.deltaTime;
                    await Awaitable.NextFrameAsync();
                }

                ball.transform.position = point;
            }
            _lineReader.ClearLine();
            _timer.OnResume();

            if (_levelBuilder.GetStarts().Count > 1)
            {
                _lineReader.IsDrawing = true;
            }
            CheckWin();
        }


        private void CheckWin()
        {
            var finishes = _levelBuilder.GetFinishes();
            var win = false;
            foreach (var finish in finishes.Where(finish=>finish.Collider2D.OverlapPoint(_lastPath[^1])))
            {
                win = finish.Id == _currentBallId;
            }

            if (!win)
            {
                ShowLosePopup();
            }
            
            win = win && _coinsCollected >= _levels.CurrentLevel.CoinPositions.Length;
            _wins.Add(win);
            
            if (_wins.Count < finishes.Count || _wallTouched)
                return;
            
            if (_wins.All(x => x))
            {
                ShowWinPopup();
            }
            else
            {
                ShowLosePopup();
            }


        }

        private void DamagerOnHit(OnDamageSignal obj)
        {
            _wallTouched = true;
            ShowLosePopup();
        }
        
        private void ShowWinPopup()
        {
            OnGameEnd();
            _levels.IncrementLevel();
            _resultPopup.OnRetry += StartNextLevel;
            _ = _resultPopup.SetWin(200, -1);

        }
        
        private void ShowLosePopup()
        {
            OnGameEnd();
            _resultPopup.OnRetry += RetryLevel;
            _ = _resultPopup.SetLose(200, -1);
        }
        
        private void OnGameEnd()
        {
            _timer.StopTimer();
            _lineReader.IsDrawing = false;
            _cancellationTokenSource.Cancel();
            _wins.Clear();
        }
        
        private void RetryLevel()
        {
            _resultPopup.OnRetry -= RetryLevel;
            StartGame();
        }

        private void StartNextLevel()
        {
            _resultPopup.OnRetry -= StartNextLevel;
            _levels.SelectLevel(_levels.CurrentLevelId.Value + 1);
            StartGame();
        }
        
        private void StartGame()
        {
            _currentBallId = -1;
            _lineReader.ClearLine();
            _levelBuilder.GenerateLevel(_levels.CurrentLevel);
            var starts = _levelBuilder.GetStarts();
            _lineReader.SetStartPoints(starts);
            _lineReader.IsDrawing = true;
            _wallTouched = false;
            _timer.Initialize(_roundTime);
            _cancellationTokenSource = new CancellationTokenSource();
            _timer.StartTimer();
        }
        
        public void OnPause()
        {
            _isPaused = true;
        }

        public void OnResume()
        {
            _isPaused = false;
        }
    }
}