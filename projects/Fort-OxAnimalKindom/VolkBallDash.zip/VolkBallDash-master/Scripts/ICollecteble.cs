﻿using VolkCore.Collections;

namespace VolkBallDash
{
    public interface ICollecteble : IItem { }
}