﻿using UnityEngine;

namespace VolkBallDash
{
    public class Ball : MonoBehaviour
    {
        [SerializeField] private SpriteRenderer _spriteRenderer;
        [SerializeField] private Sprite[] _sprites;
        public int Id;
        public void SetColor(int id)
        {
            _spriteRenderer.sprite = _sprites[id];
            Id = id;
        }
    }
}