﻿using System;
using Save;
using UnityEngine;
using VolkBallDash.ItemPools;
using VolkBallDash.Signal;
using VolkCore.Collections;
using VolkCore.Game;
using VolkCore.Save;
using VolkCore.SceneManagement;
using VolkCore.Signals;
using VolkCore.UI;
using Zenject;

namespace VolkBallDash
{
    public class BallDashInstaller : ASceneInstaller
    {

        [SerializeField] private TopPanel _topPanel;
        [SerializeField] private ResultPopup _resultPopup;
        [SerializeField] private string _timerUiFormat = "TIME: {0}";
        [Space]
        [SerializeField] private ALevelFactory<LevelData> _levelFactory;
        [SerializeField] private Coin _coinPrefab;
        [SerializeField] private Start _startPrefab;
        [SerializeField] private Finish _finishPrefab;
        [SerializeField] private Wall _wallPrefab;
        [SerializeField] private LineReader _lineReader;
        [SerializeField] private LineRenderer _lineRendererPrefab;
        [SerializeField] private BallDashLevelBuilder _ballDashLevelBuilder;
        [SerializeField] private int _roundTimeSeconds = 30;

        public override void InstallBindings()
        {
            if (!CheckAndLogDependencies())
                return;

            Container.Bind<TopPanel>().FromInstance(_topPanel);
            Container.Bind<ResultPopup>().FromInstance(_resultPopup);
            Container.Bind<PauseManager>().ToSelf().AsSingle();

            Container.BindInterfacesAndSelfTo<Timer>().FromNew().AsSingle();
            Container.Bind<string>().WithId("TimerStringFormat").FromInstance(_timerUiFormat).AsCached();
            Container.Bind<TimeSpan>().FromInstance(new TimeSpan(0,0,_roundTimeSeconds)).AsCached();

            Container.Bind<BallDashLevelBuilder>().FromInstance(_ballDashLevelBuilder);
            Container.Bind<LineReader>().FromInstance(_lineReader).AsSingle();

            Container.Bind<ALevelFactory<LevelData>>().To<BallDashLevelFactory>()
                .FromScriptableObject(_levelFactory).AsSingle();
            Container.Bind(typeof(AGameLevels<LevelData>), typeof(IInitializable), typeof(ILevelProgress))
                .To<BallDashLevels>().AsSingle();

            Container.BindMemoryPool<Coin, CoinPool>()
                .WithInitialSize(10)
                .FromComponentInNewPrefab(_coinPrefab)
                .UnderTransform(_ballDashLevelBuilder.transform);

            Container.BindMemoryPool<Start, StartPool>()
                .WithInitialSize(2)
                .FromComponentInNewPrefab(_startPrefab)
                .UnderTransform(_ballDashLevelBuilder.transform);

            Container.BindMemoryPool<Finish, FinishPool>()
                .WithInitialSize(2)
                .FromComponentInNewPrefab(_finishPrefab)
                .UnderTransform(_ballDashLevelBuilder.transform);

            Container.BindMemoryPool<Wall, WallPool>()
                .WithInitialSize(5)
                .FromComponentInNewPrefab(_wallPrefab)
                .UnderTransform(_ballDashLevelBuilder.transform);

            Container.BindMemoryPool<LineRenderer, LineRendererPool>()
                .WithInitialSize(3)
                .FromComponentInNewPrefab(_lineRendererPrefab)
                .UnderTransform(_lineReader.transform);


            Container.BindInterfacesAndSelfTo<BallDash>().AsSingle();

            Container.DeclareSignal<LevelSelectedSignal>();
            Container.DeclareSignal<CollectedSignals>();
            Container.DeclareSignal<OnDamageSignal>();
            Container.DeclareSignal<OnLineDrawnSignal>();
        }
    }
}

