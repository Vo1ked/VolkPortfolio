﻿using VolkCore.Collections;

namespace VolkBallDash
{
    public interface IDamageDealer : IItem { }
}