﻿using System.Linq;
using UnityEngine;
using Zenject;

namespace VolkBallDash.Tools
{
    public class BallDashLevelSaver : MonoBehaviour
    {
        [SerializeField] private BallDashLevelFactory _ballDashLevelFactory;
        [SerializeField] private GameObject _ballDashContainer;
        [SerializeField] private int levelNumber;
        [Inject] private BallDashLevelBuilder _levelBuilder;
        
        [SerializeField] private Start _startPrefab;
        [SerializeField] private Finish _finishPrefab;
        [SerializeField] private Coin _coinPrefab;
        [SerializeField] private Wall _wallPrefab;

        public void SaveLevel()
        {
            LevelData newLevelData = GatherLevelData();

            var existingLevel = _ballDashLevelFactory.BallDashLevelsData.FirstOrDefault(ld => ld.Level == newLevelData.Level);
            if (existingLevel.Level != 0) 
            {
#if UNITY_EDITOR
                
                if (UnityEditor.EditorUtility.DisplayDialog("Збереження рівня",
                    "Цей рівень вже існує. Ви дійсно хочете перезаписати його?",
                    "Так", "Ні"))
                {
                    SaveNewLevel(newLevelData);
                    levelNumber++;
                }
#endif
            }
            else
            {
                SaveNewLevel(newLevelData);
                levelNumber++;
            }
        }

        public void LoadLevel()
        {
            while (_ballDashContainer.transform.childCount > 0)
            {
                foreach (Transform go in _ballDashContainer.transform)
                {
                    DestroyImmediate(go.gameObject);
                }
            }
            
            for (var i = 0; i < _ballDashLevelFactory.BallDashLevelsData[levelNumber].StartPositions.Length; i++)
            {
                var position = _ballDashLevelFactory.BallDashLevelsData[levelNumber].StartPositions[i];
                var start = Instantiate(_startPrefab,position, Quaternion.identity, transform);
                start.Ball.SetColor(i);
            }

            for (var i = 0; i < _ballDashLevelFactory.BallDashLevelsData[levelNumber].FinishPositions.Length; i++)
            {
                var position = _ballDashLevelFactory.BallDashLevelsData[levelNumber].FinishPositions[i];
                var finish = Instantiate(_finishPrefab,position, Quaternion.identity, transform);
                finish.SetColor(i);
            }

            foreach (var position in _ballDashLevelFactory.BallDashLevelsData[levelNumber].CoinPositions)
            {
                var coin = Instantiate(_coinPrefab,position, Quaternion.identity, transform);
            }

            foreach (var position in _ballDashLevelFactory.BallDashLevelsData[levelNumber].WallPositions)
            {
                var wall = Instantiate(_wallPrefab,position, Quaternion.identity, transform);
            }

        }

        private LevelData GatherLevelData()
        {
            Vector2[] coinPositions = _ballDashContainer.GetComponentsInChildren<Coin>()
                .Select(coin => (Vector2)coin.transform.localPosition).ToArray();

            Vector2[] wallPositions = _ballDashContainer.GetComponentsInChildren<Wall>()
                .Select(wall => (Vector2)wall.transform.localPosition).ToArray();

            Vector2[] startPositions = _ballDashContainer.GetComponentsInChildren<Start>()
                .Select(start => (Vector2)start.transform.localPosition).ToArray();

            Vector2[] finishPositions = _ballDashContainer.GetComponentsInChildren<Finish>()
                .Select(finish => (Vector2)finish.transform.localPosition).ToArray();

            return new LevelData
            {
                Level = levelNumber,
                CoinPositions = coinPositions,
                WallPositions = wallPositions,
                StartPositions = startPositions,
                FinishPositions = finishPositions
            };
        }

        private void SaveNewLevel(LevelData newLevelData)
        {
            var levels = _ballDashLevelFactory.BallDashLevelsData.ToList();
            if (levelNumber >= levels.Count)
            {
                levels.Add(newLevelData);
            }
            else
            {
                levels[levelNumber] = newLevelData;
            }
            _ballDashLevelFactory.SetLevelsData(levels.ToArray()); 
        }
    }
}
